# ============================================================================
# prep_data.R
# ----------------------------------------------------------------------------
# FIT5147 DVP Part 2 - Diet Quality & Health Outcomes in Australia
# Author: Zekai Zheng (STUDENT_ID), Applied 09
#
# PURPOSE
#   This script performs ALL data wrangling OUTSIDE of the Shiny app (as the
#   unit recommends for performance) and writes four cached .rds files that
#   app.R reads on startup:
#       data/diet_by_age.rds         - healthy/core vs discretionary share by life stage
#       data/sugar_disease.rds       - sugar intake vs disease prevalence by age band
#       data/food_group_contrib.rds  - food-group contribution to the obesogenic proxy
#       data/beverage_monthly.rds    - monthly beverage trends (2018-2024)
#
# DATA SOURCES
#   1. NNPASDC05.xlsx                          (ABS NNPAS, 2023 release)
#        Sheet "Table 5.1_Means Persons"
#        Daily intake of AUSNUT food groups by age (grams/day, Persons 2y+).
#   2. 4316DO001_202324_ESTIMATES.xlsx         (ABS Apparent Consumption, 2023-24)
#        Sheet "Table 5.3"
#        Energy (kJ) per capita per day from selected AUSNUT food groupings,
#        by month, July 2018 - June 2024.
#
#   The above two workbooks are mandatory; the script stops with a clear
#   message if they cannot be found.
#
#   Disease-prevalence values (used in the Sugar & Disease tab) are
#   documented constants taken from the ABS National Health Survey 2022
#   (cat. 4364.0.55.001). If you have access to that survey's data cube,
#   the same wrangling pattern can be used to refresh them.
#
# HOW TO RUN
#   1. Place the two .xlsx files in data/raw/ with these exact filenames:
#        data/raw/NNPASDC05.xlsx
#        data/raw/4316DO001_202324_ESTIMATES.xlsx
#   2. From RStudio:  source("prep_data.R")
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readxl)
  library(stringr)
  library(lubridate)
})

RAW_DIR <- "data/raw"
OUT_DIR <- "data"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

F_NNPAS <- file.path(RAW_DIR, "NNPASDC05.xlsx")
F_APC   <- file.path(RAW_DIR, "4316DO001_202324_ESTIMATES.xlsx")

if (!file.exists(F_NNPAS) || !file.exists(F_APC)) {
  stop(
    "Raw ABS workbooks not found. Please place the following files in ",
    "data/raw/ and re-run prep_data.R:\n",
    "  - NNPASDC05.xlsx\n",
    "  - 4316DO001_202324_ESTIMATES.xlsx"
  )
}

# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
to_num <- function(x) {
  # Coerce a value that may be character ("n.p.", "*0.1", "**", etc.) to numeric.
  if (is.numeric(x)) return(x)
  x <- as.character(x)
  x <- gsub("^\\s*\\*+\\s*", "", x)    # strip leading * markers
  x <- gsub(",", "", x, fixed = TRUE)  # strip thousands separators
  x[x %in% c("n.p.", "np", "-", "")] <- NA
  suppressWarnings(as.numeric(x))
}

# Read NNPAS Table 5.1 into a tidy frame (food_group + canonical age cols).
read_nnpas_5_1 <- function() {
  raw <- read_excel(F_NNPAS, sheet = "Table 5.1_Means Persons", skip = 5,
                    col_names = FALSE, .name_repair = "minimal")
  # Row 1 of `raw` (Excel row 6) is the age-group header.
  age_hdr <- as.character(unlist(raw[1, ]))
  age_hdr[1] <- "food_group"
  age_hdr <- gsub("\\n", " ", age_hdr)
  age_hdr <- gsub("\\s+", " ", age_hdr)
  age_hdr <- str_trim(age_hdr)
  colnames(raw) <- age_hdr
  # Drop the header row and the "Mean (grams)" sub-header row.
  raw <- raw[-c(1, 2), ]

  # Canonical column names. The source uses unicode en-dashes (\u2013) which
  # cause locale issues on Windows; normalise all dashes to ASCII hyphens.
  norm_dash <- function(x) {
    x <- gsub("\u2013", "-", x, fixed = TRUE)  # en-dash
    x <- gsub("\u2014", "-", x, fixed = TRUE)  # em-dash
    x
  }
  names(raw) <- norm_dash(names(raw))

  age_map <- c(
    "2-4"                    = "age_2_4",
    "5-11"                   = "age_5_11",
    "12-17"                  = "age_12_17",
    "18-29"                  = "age_18_29",
    "30-49"                  = "age_30_49",
    "50-64"                  = "age_50_64",
    "65-74"                  = "age_65_74",
    "75 years and over"      = "age_75_plus",
    "2-17"                   = "age_2_17",
    "18 years and over"      = "age_18_plus",
    "Total 2 years and over" = "age_total_2_plus"
  )
  matched <- intersect(names(age_map), names(raw))
  for (nm in matched) names(raw)[names(raw) == nm] <- age_map[[nm]]

  age_cols <- intersect(unname(age_map), names(raw))
  raw %>%
    mutate(food_group = str_trim(as.character(food_group)),
           across(all_of(age_cols), to_num)) %>%
    filter(!is.na(food_group), food_group != "")
}

# Population-weighted combination across NNPAS bands.
combine_bands <- function(values, weights) {
  v <- as.numeric(values)
  w <- as.numeric(weights)
  w[is.na(w) | w <= 0] <- 0
  if (sum(w) == 0) return(mean(v, na.rm = TRUE))
  sum(v * w, na.rm = TRUE) / sum(w, na.rm = TRUE)
}

# ============================================================================
# 1. DIET BY LIFE STAGE - share of total intake (g/day) from healthy/core
#                        vs discretionary food groups, by age band
# ============================================================================
build_diet_by_age <- function() {
  message("[1/4] Reading NNPAS Table 5.1 (intake by age)...")
  raw <- read_nnpas_5_1()

  # Healthy/core food groups (Australian Dietary Guidelines basis).
  # NOTE: water and alcoholic beverages are deliberately excluded so the
  # composition reflects FOOD rather than overall fluid weight.
  healthy <- c(
    "100% Fruit and vegetable juices",
    "Fruit products and dishes",
    "Vegetable products and dishes",
    "Legume and pulse products and dishes",
    "Cereals and cereal products",
    "Fish and seafood products and dishes",
    "Egg products and dishes",
    "Milk products and dishes",
    "Seed and nut products and dishes",
    "Meat, poultry and game products and dishes"
  )
  # Discretionary food groups (ABS Apparent Consumption discretionary list).
  discretionary <- c(
    "Soft drinks, and flavoured mineral waters",
    "Cordials",
    "Electrolyte, energy and fortified drinks",
    "Fruit and vegetable drinks",
    "Cereal based products and dishes",
    "Snack foods",
    "Sugar products and dishes",
    "Confectionery and cereal, nut, fruit and seed bars"
  )

  classify <- raw %>%
    mutate(category = case_when(
      food_group %in% healthy ~ "healthy",
      food_group %in% discretionary ~ "discretionary",
      TRUE ~ NA_character_
    )) %>%
    filter(!is.na(category))

  pop_row <- raw %>% filter(food_group == "Total persons ('000)")
  if (nrow(pop_row) == 0) stop("Could not find 'Total persons' row in Table 5.1.")

  life_stage_cols <- list(
    "Children (2-12)"     = c("age_2_4", "age_5_11"),
    "Adolescents (13-17)" = c("age_12_17"),
    "Adults (18-64)"      = c("age_18_29", "age_30_49", "age_50_64"),
    "Older adults (65+)"  = c("age_65_74", "age_75_plus")
  )

  # For each life stage, sum healthy and discretionary group grams using
  # population weights, then convert to share (%).
  result <- lapply(seq_along(life_stage_cols), function(i) {
    ls   <- names(life_stage_cols)[i]
    cols <- life_stage_cols[[i]]
    w    <- as.numeric(unlist(pop_row[1, cols]))

    # Sum across food groups within each category for each NNPAS band, then
    # combine across bands by population weighting.
    by_cat <- classify %>%
      group_by(category) %>%
      summarise(across(all_of(cols), \(x) sum(x, na.rm = TRUE)),
                .groups = "drop")

    cat_totals <- sapply(by_cat$category, function(cat) {
      vals <- as.numeric(by_cat %>% filter(category == cat) %>% select(all_of(cols)))
      combine_bands(vals, w)
    })

    total <- sum(cat_totals)
    pop_n <- round(sum(w, na.rm = TRUE) * 1000)   # NNPAS unit is '000

    tibble(
      life_stage         = ls,
      order              = i,
      healthy_pct        = round(100 * cat_totals[["healthy"]]       / total, 1),
      discretionary_pct  = round(100 * cat_totals[["discretionary"]] / total, 1),
      n                  = pop_n
    )
  })
  bind_rows(result)
}

# ============================================================================
# 2. SUGAR INTAKE vs DISEASE PREVALENCE - by aligned age band
# ============================================================================
build_sugar_disease <- function() {
  message("[2/4] Reading NNPAS Table 5.1 (sugar intake by age)...")
  raw <- read_nnpas_5_1()

  sugar_row <- raw %>% filter(food_group == "Sugar products and dishes")
  pop_row   <- raw %>% filter(food_group == "Total persons ('000)")
  if (nrow(sugar_row) == 0) stop("Could not find 'Sugar products and dishes' row.")

  band_map <- list(
    "2-17"  = c("age_2_4", "age_5_11", "age_12_17"),
    "18-29" = c("age_18_29"),
    "30-49" = c("age_30_49"),
    "50-64" = c("age_50_64"),
    "65-74" = c("age_65_74"),
    "75+"   = c("age_75_plus")
  )
  bands <- names(band_map)
  sugar_by_band <- sapply(band_map, function(cols) {
    v <- as.numeric(unlist(sugar_row[1, cols]))
    w <- as.numeric(unlist(pop_row[1, cols]))
    combine_bands(v, w)
  })

  # ---- Disease prevalence (ABS National Health Survey 2022) ---------------
  # Documented constants; replace with full wrangling if the NHS cube is
  # available in data/raw/.
  disease_lookup <- tribble(
    ~age_band, ~diabetes_pct, ~heart_pct, ~kidney_pct,
    "2-17",         0.2,         0.4,         0.3,
    "18-29",        1.8,         1.2,         0.9,
    "30-49",        4.6,         3.1,         2.0,
    "50-64",       10.2,         7.5,         4.1,
    "65-74",       14.6,        12.4,         6.0,
    "75+",         16.0,        18.2,         9.3
  )

  tibble(
    age_band    = bands,
    order       = seq_along(bands),
    sugar_g_day = round(unname(sugar_by_band), 1)
  ) %>%
    left_join(disease_lookup, by = "age_band")
}

# ============================================================================
# 3. FOOD-GROUP CONTRIBUTION to the OBESOGENIC DIET PROXY
# ============================================================================
build_food_group_contrib <- function() {
  message("[3/4] Building food-group contribution table from NNPAS Table 5.1...")
  raw <- read_nnpas_5_1()
  pop_row <- raw %>% filter(food_group == "Total persons ('000)")

  age_map <- list(
    "2-17"  = c("age_2_4", "age_5_11"),
    "13-17" = c("age_12_17"),
    "18-64" = c("age_18_29", "age_30_49", "age_50_64"),
    "65+"   = c("age_65_74", "age_75_plus")
  )
  group_map <- c(
    "SSBs"            = "Soft drinks, and flavoured mineral waters",
    "Confectionery"   = "Confectionery and cereal, nut, fruit and seed bars",
    "Cakes"           = "Cakes, muffins, scones, cake-type desserts",
    "Snacks"          = "Snack foods",
    "Processed meats" = "Processed meat",
    "Other"           = "Sugar products and dishes"   # remaining discretionary
  )

  rows <- list()
  for (ls in names(age_map)) {
    cols <- age_map[[ls]]
    w    <- as.numeric(unlist(pop_row[1, cols]))

    grams <- sapply(names(group_map), function(disp) {
      r <- raw %>% filter(food_group == group_map[[disp]])
      if (nrow(r) == 0) return(NA_real_)
      vals <- as.numeric(unlist(r[1, cols]))
      combine_bands(vals, w)
    })
    total <- sum(grams, na.rm = TRUE)

    rows[[ls]] <- tibble(
      life_stage       = ls,
      food_group       = names(group_map),
      grams_per_day    = round(grams, 2),
      contribution_pct = round(100 * grams / total, 1)
    )
  }

  bind_rows(rows) %>%
    mutate(
      life_stage = factor(life_stage, levels = names(age_map)),
      food_group = factor(food_group,
                          levels = c("SSBs", "Confectionery", "Cakes",
                                     "Snacks", "Processed meats", "Other"))
    )
}

# ============================================================================
# 4. MONTHLY BEVERAGE TRENDS - Table 5.3 of Apparent Consumption 2023-24
# ============================================================================
build_beverage_monthly <- function() {
  message("[4/4] Reading Apparent Consumption Table 5.3 (monthly beverages)...")
  raw <- read_excel(F_APC, sheet = "Table 5.3", skip = 6,
                    col_names = FALSE, .name_repair = "minimal")
  hdr <- as.character(unlist(raw[1, ]))
  colnames(raw) <- hdr
  raw <- raw[-1, ]
  month_cols <- which(grepl("^[A-Z][a-z]{2} [0-9]{4}$", names(raw)))
  if (length(month_cols) == 0) stop("Could not find month columns in Table 5.3.")
  # Find the food-group name column (the one with parenthetical footnote markers
  # like "Food group(d)(e)"), excluding the food-group-code column.
  group_col <- which(grepl("^Food group\\(", names(raw)))[1]
  if (is.na(group_col)) group_col <- 3

  sugar_sweet   <- c("Electrolyte, energy and fortified drinks",
                     "Coffee and coffee substitutes")
  intense_sweet <- c("Soft drinks and flavoured mineral waters",
                     "Cordials")

  long <- raw %>%
    rename(food_group = !!names(raw)[group_col]) %>%
    mutate(food_group = str_trim(as.character(food_group))) %>%
    filter(food_group %in% c(sugar_sweet, intense_sweet)) %>%
    select(food_group, all_of(names(raw)[month_cols])) %>%
    pivot_longer(-food_group, names_to = "month_str", values_to = "kj_per_capita") %>%
    mutate(
      kj_per_capita = to_num(kj_per_capita),
      date          = my(month_str),
      category      = case_when(
        food_group %in% sugar_sweet   ~ "Sugar-sweetened",
        food_group %in% intense_sweet ~ "Intense-sweetened"
      )
    ) %>%
    filter(!is.na(date), !is.na(kj_per_capita))

  long %>%
    group_by(date, category) %>%
    summarise(kj_per_capita = sum(kj_per_capita, na.rm = TRUE),
              .groups = "drop") %>%
    arrange(category, date)
}

# ============================================================================
# RUN AND CACHE
# ============================================================================
diet_by_age        <- build_diet_by_age()
sugar_disease      <- build_sugar_disease()
food_group_contrib <- build_food_group_contrib()
beverage_monthly   <- build_beverage_monthly()

saveRDS(diet_by_age,        file.path(OUT_DIR, "diet_by_age.rds"))
saveRDS(sugar_disease,      file.path(OUT_DIR, "sugar_disease.rds"))
saveRDS(food_group_contrib, file.path(OUT_DIR, "food_group_contrib.rds"))
saveRDS(beverage_monthly,   file.path(OUT_DIR, "beverage_monthly.rds"))

message("\nCached datasets written to ", OUT_DIR, "/:")
message("  - diet_by_age.rds        (", nrow(diet_by_age), " rows)")
message("  - sugar_disease.rds      (", nrow(sugar_disease), " rows)")
message("  - food_group_contrib.rds (", nrow(food_group_contrib), " rows)")
message("  - beverage_monthly.rds   (", nrow(beverage_monthly), " rows)")
