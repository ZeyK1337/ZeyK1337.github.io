# ============================================================================
# app.R
# ----------------------------------------------------------------------------
# FIT5147 DVP Part 2 - Diet Quality & Health Outcomes in Australia
# An interactive narrative dashboard for public-health communicators.
#
# Author: Zekai Zheng (STUDENT_ID), Applied 09
# Tutors: Yiheng Liang, Niranjan Nanjunda
#
# DESIGN BASIS (FDS Sheet 5):
#   Tab 1 Overview          - three KPI cards summarising the headline findings
#   Tab 2 Diet by life stage- 100% stacked bar: healthy vs discretionary share
#   Tab 3 Sugar & disease   - scatter (sugar vs diabetes) linked to a disease bar
#   Tab 4 Driver drill-down - 100% stacked contribution to the obesogenic proxy
#   Tab 5 About the data    - sources, definitions, how to use
#
# THEORY APPLIED:
#   - Shneiderman (1996) overview-zoom-filter-detail mantra (tab + sidebar layout)
#   - Cleveland & McGill (1984) position-on-a-common-scale encodings throughout
#   - Tufte (2001) minimal chartjunk, high data-ink
#   - Segel & Heer (2010) partitioned-poster narrative with annotation layer
#   - Harrower & Brewer (2003) colourblind-safe palette
#
# TO RUN:
#   1. source("prep_data.R")   # builds the cached .rds files (run once)
#   2. Click "Run App" in RStudio, or shiny::runApp()
# ============================================================================

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
  library(bsicons)
  library(ggplot2)
  library(plotly)
  library(dplyr)
  library(tidyr)
  library(scales)
  library(DT)
})

# ----------------------------------------------------------------------------
# Load cached data (build it if the caches are missing)
# ----------------------------------------------------------------------------
if (!all(file.exists(c("data/diet_by_age.rds",
                       "data/sugar_disease.rds",
                       "data/food_group_contrib.rds",
                       "data/beverage_monthly.rds")))) {
  message("Cached data not found - running prep_data.R ...")
  source("prep_data.R")
}

diet_by_age        <- readRDS("data/diet_by_age.rds")
sugar_disease      <- readRDS("data/sugar_disease.rds")
food_group_contrib <- readRDS("data/food_group_contrib.rds")
beverage_monthly   <- readRDS("data/beverage_monthly.rds")

# ----------------------------------------------------------------------------
# Palette & theme (consistent across all panels - Munzner consistency principle)
# ----------------------------------------------------------------------------
COL_HEALTHY    <- "#2C7B3F"   # green  - healthy / core foods
COL_DISCRETION <- "#D7301F"   # red    - discretionary foods
ACCENT         <- "#0F4C81"

# Qualitative palette for the six food groups (ColorBrewer-derived)
FOOD_COLOURS <- c(
  "SSBs"            = "#D7301F",
  "Confectionery"   = "#FC8D59",
  "Cakes"           = "#FDCC8A",
  "Snacks"          = "#7570B3",
  "Processed meats" = "#01665E",
  "Other"           = "#5AAE61"
)

# Age-band colours for the scatter (sequential by age)
AGE_COLOURS <- c(
  "2-17"  = "#1f78b4", "18-29" = "#33a02c", "30-49" = "#6a3d9a",
  "50-64" = "#ff7f00", "65-74" = "#e31a1c", "75+"   = "#b15928"
)

theme_dvp <- function() {
  theme_minimal(base_size = 13) +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      plot.title = element_text(face = "bold", size = 14, colour = "#222222"),
      axis.title = element_text(colour = "#444444"),
      legend.position = "top",
      legend.title = element_blank(),
      plot.margin = margin(10, 16, 10, 10)
    )
}

# Disease label helper for the linked bar chart
DISEASE_COLS <- c(diabetes_pct = "Diabetes",
                  heart_pct    = "Heart disease",
                  kidney_pct   = "Kidney disease")

# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------
ui <- page_sidebar(
  title = "Diet Quality & Health Outcomes in Australia",
  theme = bs_theme(version = 5, primary = ACCENT, base_font = font_google("Open Sans")),

  sidebar = sidebar(
    width = 300,
    title = "Explore",
    helpText("A guided tour through three findings from the ABS data. ",
             "Adjust the controls below; every chart updates."),
    tags$hr(),
    checkboxGroupInput(
      "life_stages", "Life stage",
      choices  = c("Children (2-12)", "Adolescents (13-17)",
                   "Adults (18-64)", "Older adults (65+)"),
      selected = c("Children (2-12)", "Adolescents (13-17)",
                   "Adults (18-64)", "Older adults (65+)")
    ),
    selectInput(
      "metric", "Metric (driver tab)",
      choices  = c("Obesogenic proxy share" = "proxy"),
      selected = "proxy"
    ),
    selectInput(
      "food_group", "Food group to zoom (driver tab)",
      choices  = names(FOOD_COLOURS),
      selected = "SSBs"
    ),
    selectInput(
      "disease", "Disease (sugar tab)",
      choices  = c("Diabetes" = "diabetes_pct",
                   "Heart disease" = "heart_pct",
                   "Kidney disease" = "kidney_pct"),
      selected = "diabetes_pct"
    ),
    tags$hr(),
    actionButton("reset", "\u21BB Reset filters",
                 class = "btn-warning w-100")
  ),

  navset_card_tab(
    id = "tabs",

    # ---- TAB 1: OVERVIEW ----------------------------------------------------
    nav_panel(
      "1. Overview",
      h4("Australian diets vary by life stage \u2014 and so do health outcomes"),
      p(class = "text-muted",
        "Adolescents and adults draw the highest share of their food intake ",
        "from discretionary items (soft drinks, confectionery, snacks); ",
        "children and older adults eat closer to the core-foods recommendation. ",
        "Sugar-product intake co-varies with chronic-disease prevalence across ",
        "age bands \u2014 though age is a strong confounder, which the dashboard ",
        "makes explicit on Tab 3."),
      layout_columns(
        col_widths = c(4, 4, 4),
        value_box(
          title = "Adolescent (13-17) share of food from discretionary items",
          value = textOutput("kpi_adol"),
          showcase = bsicons::bs_icon("cup-straw"),
          theme = "danger"
        ),
        value_box(
          title = "Discretionary-share gap, 13-17 vs 65+",
          value = textOutput("kpi_gap"),
          showcase = bsicons::bs_icon("graph-up"),
          theme = "warning"
        ),
        value_box(
          title = "Sugar \u2194 diabetes correlation (age-aggregated)",
          value = textOutput("kpi_r"),
          showcase = bsicons::bs_icon("activity"),
          theme = "primary"
        )
      ),
      tags$br(),
      p(class = "text-muted small",
        "Use the tabs above to move through the story: diet composition by life ",
        "stage, then the sugar\u2013disease association, then the food groups that ",
        "drive the obesogenic diet proxy.")
    ),

    # ---- TAB 2: DIET BY LIFE STAGE -----------------------------------------
    nav_panel(
      "2. Diet by life stage",
      layout_columns(
        col_widths = c(8, 4),
        card(
          card_header("Share of energy: Healthy/core vs Discretionary"),
          plotlyOutput("plot_lifestage", height = "460px"),
          downloadButton("dl_lifestage", "Download data (CSV)",
                         class = "btn-sm btn-outline-secondary mt-2")
        ),
        card(
          card_header("What the chart says"),
          uiOutput("narrative_lifestage")
        )
      )
    ),

    # ---- TAB 3: SUGAR & DISEASE --------------------------------------------
    nav_panel(
      "3. Sugar & disease",
      layout_columns(
        col_widths = c(7, 5),
        card(
          card_header("Sugar intake vs disease prevalence, by age band"),
          plotlyOutput("plot_scatter", height = "420px"),
          downloadButton("dl_sugar", "Download data (CSV)",
                         class = "btn-sm btn-outline-secondary mt-2")
        ),
        card(
          card_header("Linked view: prevalence for the selected band"),
          plotlyOutput("plot_disease_bar", height = "420px")
        )
      ),
      div(
        class = "alert alert-warning mt-2",
        role = "alert",
        tags$b("\u26A0 Caveat: association is not causation. "),
        "Disease prevalence also rises sharply with age, which may explain much ",
        "of the apparent sugar\u2013disease relationship. Treat these correlations ",
        "as exploratory, not causal."
      )
    ),

    # ---- TAB 4: DRIVER DRILL-DOWN ------------------------------------------
    nav_panel(
      "4. Driver drill-down",
      card(
        card_header("Contribution of each food group to the obesogenic diet proxy"),
        plotlyOutput("plot_contrib", height = "360px"),
        downloadButton("dl_contrib", "Download data (CSV)",
                       class = "btn-sm btn-outline-secondary mt-2"),
        p(class = "text-muted small mt-1",
          "Tip: click any coloured segment to load that food group into the ",
          "zoom panel below.")
      ),
      layout_columns(
        col_widths = c(7, 5),
        card(
          card_header(textOutput("zoom_title")),
          plotlyOutput("plot_zoom", height = "300px")
        ),
        card(
          card_header("Take-away"),
          uiOutput("narrative_drivers")
        )
      ),
      card(
        card_header("National beverage-consumption trend, 2018-2024"),
        p(class = "text-muted small",
          "Apparent consumption of sugar-sweetened and intense-sweetened ",
          "beverages, mean kJ per capita per day. Provides temporal context ",
          "for the SSB-dominated contribution shown above."),
        plotlyOutput("plot_beverage", height = "350px")
      )
    ),

    # ---- TAB 5: ABOUT THE DATA ---------------------------------------------
    nav_panel(
      "5. About the data",
      card(
        card_header("Sources, definitions and how to read this dashboard"),
        h5("Data sources"),
        tags$ul(
          tags$li(
            "Australian Bureau of Statistics (2023). ",
            tags$em("National Nutrition and Physical Activity Survey"),
            ", Table 5.1. ",
            tags$a(href = "https://www.abs.gov.au/statistics/health/food-and-nutrition/national-nutrition-and-physical-activity-survey/latest-release",
                   target = "_blank", "ABS link")
          ),
          tags$li(
            "Australian Bureau of Statistics (2021). ",
            tags$em("Health: Census"), ", Table 1. ",
            tags$a(href = "https://www.abs.gov.au/statistics/health/health-conditions-and-risks/health-census/latest-release",
                   target = "_blank", "ABS link")
          ),
          tags$li(
            "Australian Bureau of Statistics (2024). ",
            tags$em("Apparent Consumption of Selected Foodstuffs 2018-24"),
            ", Table 5.3. ",
            tags$a(href = "https://www.abs.gov.au/statistics/health/food-and-nutrition/apparent-consumption-selected-foodstuffs-australia/latest-release",
                   target = "_blank", "ABS link")
          )
        ),
        h5("Key definitions"),
        tags$ul(
          tags$li(tags$b("Healthy / core foods: "),
                  "vegetables, fruit, whole grains, legumes, nuts, dairy, lean meats, water."),
          tags$li(tags$b("Discretionary foods: "),
                  "soft drinks, confectionery, cakes, snacks, processed meats."),
          tags$li(tags$b("Obesogenic diet proxy: "),
                  "a standardised weighted sum of discretionary intake relative to ",
                  "core-food intake. It is an exploratory dietary-risk index, ",
                  tags$em("not"), " a measure of clinical obesity.")
        ),
        h5("How to use"),
        p("Pick one or more life stages in the sidebar, choose a metric and a ",
          "food group to zoom, then click through tabs 1\u20134. Hover any chart ",
          "element for exact values. In the driver tab, change the ",
          tags$em("Food group to zoom"), " control \u2014 or click a bar segment \u2014 ",
          "to repopulate the lower chart."),
        tags$hr(),
        h5("Underlying data (diet by life stage)"),
        DTOutput("data_table")
      )
    )
  )
)

# ----------------------------------------------------------------------------
# SERVER
# ----------------------------------------------------------------------------
server <- function(input, output, session) {

  # Reset button restores all controls to defaults
  observeEvent(input$reset, {
    updateCheckboxGroupInput(session, "life_stages",
      selected = c("Children (2-12)", "Adolescents (13-17)",
                   "Adults (18-64)", "Older adults (65+)"))
    updateSelectInput(session, "metric",     selected = "proxy")
    updateSelectInput(session, "food_group", selected = "SSBs")
    updateSelectInput(session, "disease",    selected = "diabetes_pct")
  })

  # Reactive: filtered life-stage diet data
  diet_filtered <- reactive({
    req(input$life_stages)
    diet_by_age %>%
      filter(life_stage %in% input$life_stages) %>%
      arrange(order)
  })

  # ---- TAB 1: KPI value boxes (computed from real data) -------------------
  output$kpi_adol <- renderText({
    v <- diet_by_age$discretionary_pct[diet_by_age$life_stage == "Adolescents (13-17)"]
    paste0(round(v, 1), "%")
  })
  output$kpi_gap <- renderText({
    adol <- diet_by_age$discretionary_pct[diet_by_age$life_stage == "Adolescents (13-17)"]
    old  <- diet_by_age$discretionary_pct[diet_by_age$life_stage == "Older adults (65+)"]
    paste0("+", round(adol - old, 1), " pp")
  })
  output$kpi_r <- renderText({
    r <- cor(sugar_disease$sugar_g_day, sugar_disease$diabetes_pct,
             use = "complete.obs")
    paste0("r = ", round(r, 2))
  })

  # ---- TAB 2: stacked bar -------------------------------------------------
  output$plot_lifestage <- renderPlotly({
    d <- diet_filtered() %>%
      pivot_longer(c(healthy_pct, discretionary_pct),
                   names_to = "type", values_to = "pct") %>%
      mutate(
        type = recode(type,
                      healthy_pct = "Healthy / core foods",
                      discretionary_pct = "Discretionary foods"),
        type = factor(type, levels = c("Discretionary foods",
                                       "Healthy / core foods")),
        life_stage = factor(life_stage, levels = diet_by_age$life_stage),
        tip = paste0(life_stage, "<br>", type, ": ", pct, "%",
                     "<br>n \u2248 ", scales::comma(n))
      )

    p <- ggplot(d, aes(x = life_stage, y = pct, fill = type, text = tip)) +
      geom_col(width = 0.62, colour = "white") +
      scale_fill_manual(values = c("Healthy / core foods" = COL_HEALTHY,
                                   "Discretionary foods"   = COL_DISCRETION)) +
      scale_y_continuous(labels = percent_format(scale = 1), limits = c(0, 100)) +
      labs(x = NULL,
           y = "Share of food intake (% of grams, water excluded)") +
      theme_dvp()

    ggplotly(p, tooltip = "text") %>%
      layout(legend = list(orientation = "v", x = 1.02, y = 1,
                           xanchor = "left", title = list(text = ""),
                           font = list(size = 10)),
             margin = list(l = 80, r = 20))
  })

  output$narrative_lifestage <- renderUI({
    adol_d <- diet_by_age$discretionary_pct[diet_by_age$life_stage == "Adolescents (13-17)"]
    old_h  <- diet_by_age$healthy_pct[diet_by_age$life_stage == "Older adults (65+)"]
    tagList(
      tags$ul(
        tags$li(paste0("Discretionary foods peak in adolescence (\u2248 ",
                       round(adol_d, 1), "% of food intake).")),
        tags$li(paste0("Older adults consume the highest share of core foods (",
                       round(old_h, 1), "%).")),
        tags$li("Adults sit between the two extremes \u2014 a gradual life-course transition."),
        tags$li(tags$em("Water is excluded so the chart reflects food composition, not fluid weight. Hover bars for grams."))
      ),
      tags$p(class = "text-primary small",
             "Next: see the sugar\u2013disease association \u2192")
    )
  })

  # ---- TAB 3: scatter + linked bar ----------------------------------------
  # Track the selected age band (click on scatter or default to 65-74)
  selected_band <- reactiveVal("65-74")

  observeEvent(event_data("plotly_click", source = "scatter"), {
    cd <- event_data("plotly_click", source = "scatter")
    if (!is.null(cd) && !is.null(cd$key)) selected_band(cd$key)
  })

  output$plot_scatter <- renderPlotly({
    dis <- input$disease
    dlab <- DISEASE_COLS[[dis]]
    d <- sugar_disease %>%
      mutate(
        yval = .data[[dis]],
        sel  = factor(ifelse(age_band == selected_band(),
                             "selected", "other"),
                      levels = c("selected", "other")),
        tip  = paste0(age_band, "<br>Sugar: ", sugar_g_day, " g/day",
                      "<br>", dlab, ": ", yval, "%")
      )

    rval <- round(cor(d$sugar_g_day, d$yval), 2)

    p <- ggplot(d, aes(x = sugar_g_day, y = yval, key = age_band, text = tip)) +
      geom_smooth(method = "lm", se = FALSE, colour = "#999999",
                  linetype = "dashed", linewidth = 0.7) +
      geom_point(aes(colour = age_band, size = sel), show.legend = c(size = FALSE)) +
      scale_colour_manual(values = AGE_COLOURS) +
      scale_size_manual(values = c("selected" = 6, "other" = 3.5)) +
      labs(x = "Sugar products intake (g/day, per capita)",
           y = paste0(dlab, " prevalence (%)"),
           title = paste0("Linear fit: r = ", rval)) +
      theme_dvp() +
      theme(legend.position = "right")

    ggplotly(p, tooltip = "text", source = "scatter")
  })

  output$plot_disease_bar <- renderPlotly({
    band <- selected_band()
    d <- sugar_disease %>%
      filter(age_band == band) %>%
      pivot_longer(c(diabetes_pct, heart_pct, kidney_pct),
                   names_to = "disease", values_to = "prev") %>%
      mutate(
        disease = recode(disease, !!!DISEASE_COLS),
        disease = factor(disease, levels = rev(unname(DISEASE_COLS))),
        tip = paste0(disease, ": ", prev, "%")
      )

    p <- ggplot(d, aes(x = prev, y = disease, fill = disease, text = tip)) +
      geom_col(width = 0.55, show.legend = FALSE) +
      scale_fill_manual(values = c("Diabetes" = "#e31a1c",
                                   "Heart disease" = "#7f0000",
                                   "Kidney disease" = "#4a1486")) +
      labs(x = "Prevalence (%)", y = NULL,
           title = paste0("Selected band: ", band)) +
      theme_dvp() +
      theme(legend.position = "none")
    
    ggplotly(p, tooltip = "text") %>%
      layout(showlegend = FALSE, title = list(y = 0.97))
  })

  # ---- TAB 4: contribution + zoom -----------------------------------------
  output$plot_contrib <- renderPlotly({
    d <- food_group_contrib %>%
      mutate(tip = paste0(life_stage, " \u2013 ", food_group, ": ",
                          contribution_pct, "%"))

    p <- ggplot(d, aes(x = contribution_pct, y = life_stage,
                       fill = food_group, text = tip, key = food_group)) +
      geom_col(width = 0.55, colour = "white") +
      scale_fill_manual(values = FOOD_COLOURS) +
      scale_x_continuous(labels = percent_format(scale = 1)) +
      labs(x = "Share of obesogenic proxy contribution (%)", y = NULL) +
      theme_dvp()

    ggplotly(p, tooltip = "text", source = "contrib") %>%
      layout(legend = list(title = list(text = ""), font = list(size = 10)),
             margin = list(t = 20))
  })

  # Click a stacked-bar segment to drive the zoom panel below it
  observeEvent(event_data("plotly_click", source = "contrib"), {
    cd <- event_data("plotly_click", source = "contrib")
    if (!is.null(cd) && !is.null(cd$key) && cd$key %in% names(FOOD_COLOURS)) {
      updateSelectInput(session, "food_group", selected = cd$key)
    }
  })

  output$zoom_title <- renderText({
    paste0("Zoom: ", input$food_group, " contribution by life stage")
  })

  output$plot_zoom <- renderPlotly({
    fg <- input$food_group
    d <- food_group_contrib %>%
      filter(food_group == fg) %>%
      mutate(tip = paste0(life_stage, ": ", contribution_pct, "%"))

    p <- ggplot(d, aes(x = life_stage, y = contribution_pct, text = tip)) +
      geom_col(width = 0.55, fill = FOOD_COLOURS[[fg]]) +
      geom_text(aes(label = paste0(contribution_pct, "%")),
                vjust = -0.4, size = 3.6, colour = "#222222") +
      scale_y_continuous(labels = percent_format(scale = 1),
                         expand = expansion(mult = c(0, 0.12))) +
      labs(x = NULL, y = "% of proxy") +
      theme_dvp()

    ggplotly(p, tooltip = "text")
  })

  output$narrative_drivers <- renderUI({
    top <- food_group_contrib %>%
      filter(food_group == "SSBs") %>%
      slice_max(contribution_pct, n = 1)
    tags$ul(
      tags$li(paste0("Sugar-sweetened beverages are by far the dominant ",
                     "contributor across every life stage, with the largest ",
                     "share (", round(top$contribution_pct, 0),
                     "%) in the ", as.character(top$life_stage), " cohort.")),
      tags$li("Confectionery, cakes and snacks each contribute under 16% in any band."),
      tags$li("In older adults the mix shifts toward cakes and processed meats."),
      tags$li(tags$em("Change the 'Food group to zoom' selector in the sidebar to compare any group."))
    )
  })

  # Beverage time-series trend (Apparent Consumption 2018-24)
  output$plot_beverage <- renderPlotly({
    d <- beverage_monthly %>%
      mutate(tip = paste0(format(date, "%b %Y"), "<br>",
                          category, ": ", round(kj_per_capita, 1), " kJ/day"))
    p <- ggplot(d, aes(x = date, y = kj_per_capita,
                       colour = category, group = category, text = tip)) +
      geom_line(linewidth = 0.8) +
      geom_point(size = 1.2, alpha = 0.6) +
      scale_colour_manual(values = c(
        "Sugar-sweetened"   = COL_DISCRETION,
        "Intense-sweetened" = "#E07B00"
      )) +
      scale_x_date(date_breaks = "1 year", date_labels = "%Y") +
      labs(x = NULL, y = "kJ per capita per day", colour = NULL) +
      theme_dvp()
    ggplotly(p, tooltip = "text") %>%
      layout(legend = list(orientation = "h", x = 0, y = 1.12, yanchor = "bottom"),
             margin = list(t = 60, l = 80))
  })

  # ---- TAB 5: data table --------------------------------------------------
  output$data_table <- renderDT({
    datatable(
      diet_by_age %>%
        select(`Life stage` = life_stage,
               `Healthy / core (%)` = healthy_pct,
               `Discretionary (%)` = discretionary_pct,
               `Sample (n)` = n),
      options = list(dom = "t", paging = FALSE),
      rownames = FALSE
    )
  })

  # ---- CSV download handlers (underlying data behind each chart) ----------
  output$dl_lifestage <- downloadHandler(
    filename = function() "diet_by_life_stage.csv",
    content  = function(file) {
      write.csv(diet_filtered() %>%
                  select(life_stage, healthy_pct, discretionary_pct, n),
                file, row.names = FALSE)
    }
  )
  output$dl_sugar <- downloadHandler(
    filename = function() "sugar_vs_disease.csv",
    content  = function(file) {
      write.csv(sugar_disease %>%
                  select(age_band, sugar_g_day, diabetes_pct, heart_pct, kidney_pct),
                file, row.names = FALSE)
    }
  )
  output$dl_contrib <- downloadHandler(
    filename = function() "food_group_contribution.csv",
    content  = function(file) {
      write.csv(food_group_contrib %>%
                  select(life_stage, food_group, contribution_pct),
                file, row.names = FALSE)
    }
  )
}

shinyApp(ui, server)
