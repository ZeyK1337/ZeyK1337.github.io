# FIT5147 DVP Part 2 - Diet Quality & Health Outcomes in Australia

**Author:** Zekai Zheng (STUDENT_ID) | Applied 09
**Tutors:** Yiheng Liang, Niranjan Nanjunda

An interactive narrative dashboard built with **R Shiny**, communicating
findings on Australian dietary patterns and chronic-disease prevalence to a
public-health / policymaker audience.

---

## Contents

```
.
├── app.R                # the Shiny application (UI + server)
├── prep_data.R          # data wrangling -> writes cached .rds files
├── README.md            # this file
└── data/
    ├── diet_by_age.rds          # cached: 4-row life-stage composition
    ├── sugar_disease.rds        # cached: 6-row sugar vs disease
    ├── food_group_contrib.rds   # cached: 24-row driver contribution
    ├── beverage_monthly.rds     # cached: 144-row beverage time series
    └── raw/
        ├── NNPASDC05.xlsx                          # ABS NNPAS 2023
        └── 4316DO001_202324_ESTIMATES.xlsx         # ABS Apparent Consumption
```

All four cached `.rds` datasets are shipped pre-built, so the app runs
immediately without re-running the wrangling pipeline. The two raw ABS
workbooks are also included so the marker can verify the full pipeline by
running `source("prep_data.R")` if desired.

---

## How to run

### Requirements
- R >= 4.3.0
- The packages below.

Install everything in one line (one-off, takes ~2 minutes):

```r
install.packages(c(
  "shiny", "bslib", "bsicons", "ggplot2", "plotly",
  "dplyr", "tidyr", "lubridate", "readxl", "stringr",
  "scales", "DT"
))
```

### Run
From RStudio:

1. Open `app.R`.
2. Click **Run App**.

Or from an R console in this folder:

```r
shiny::runApp()
```

To rebuild the cached datasets from the raw ABS workbooks:

```r
source("prep_data.R")
```

This re-runs the entire wrangling pipeline (~3 seconds) and over-writes the
four `.rds` files in `data/`.

---

## Using the dashboard (things easily missed)

- **Sidebar filters** apply across tabs: select one or more life stages.
- **Tab 3 (Sugar & disease):** click a point in the scatter to linked-highlight
  that age band in the right-hand disease bar chart. Change the *Disease*
  selector to switch the y-axis between diabetes, heart and kidney disease.
- **Tab 4 (Driver drill-down):** change the *Food group to zoom* selector in the
  sidebar to repopulate the lower zoom chart with any food group. Scroll down
  to see the 72-month beverage time-series panel.
- **Reset filters** button restores all controls to their defaults.
- **Hover** any chart element for exact values and sample size.

---

## Data sources

- ABS (2025). *National Nutrition and Physical Activity Survey: Food and
  Nutrients, 2023* (Table 5.1, data file `NNPASDC05.xlsx`).
- ABS (2025). *Apparent Consumption of Selected Foodstuffs, 2023-24* (cat. no.
  4316.0, data file `4316DO001_202324_ESTIMATES.xlsx`, Table 5.3).
- ABS (2023). *National Health Survey, 2022* (cat. no. 4364.0.55.001) -
  chronic-condition prevalence by age band (used as documented constants in
  `prep_data.R::build_sugar_disease()`).

## Important caveats

- **Healthy / discretionary composition** (Tab 2) is computed as a share of
  grams per day with water and alcohol excluded. The "About the data" tab,
  the chart subtitle and the hover tooltips all state this. The story is
  about food composition, not fluid weight.
- **Sugar-disease correlations** (Tab 3) are weak (r = 0.29 for diabetes, 0.46
  for heart disease, 0.44 for kidney disease) and are **associations, not
  causal claims**. Age is a strong confounder; the dashboard surfaces this
  in the same visual frame as the chart itself.
- The **obesogenic diet proxy** is an exploratory standardised index of
  discretionary intake; it is **not** a measure of clinical obesity.
