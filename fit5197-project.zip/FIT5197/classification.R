#  Part 2 Classification
#  CatBoost regression heads + continuous-score blends + cutpoints.
#  Modified for R Studio compatibility.

# ==================== 环境设置 ====================
# 建议在运行前设置工作目录（包含 csv 文件夹或 kaggle_download 文件夹）
# setwd("your_path_here") 

# 定义数据文件夹（根据实际情况修改）
work_dir <- getwd()  # 或手动指定，例如 work_dir <- "C:/data"


train.path <- "classification_train.csv"
test.path <- "classification_test.csv"
sample.path <- "classification_sample_pred_submission.csv"
output.prefix <- "ClassificationPredictLabel_XGBoostV1"

# ==================== 安装与加载包 ====================
install_if_missing <- function(pkg, repos = NULL) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    if (is.null(repos)) {
      repos <- "https://cloud.r-project.org"
    }
    try(install.packages(pkg, repos = repos), silent = TRUE)
  }
  requireNamespace(pkg, quietly = TRUE)
}

# 安装 XGBoost
if (!install_if_missing("xgboost")) {
  stop("xgboost 包安装失败。请手动运行：install.packages('xgboost')")
}
# 其他依赖包
for (pkg in c("Matrix")) {
  install_if_missing(pkg)
}

library(xgboost)

set.seed(2026)

# ==================== 常量定义 ====================
LABELS <- c(-2, -1, 0, 1, 2)
FOLDS <- 5
SEEDS <- c(11, 22)
CUTPOINT_TRIALS <- 1800
BLEND_CUTPOINT_TRIALS <- 900

# ==================== 辅助函数（与原脚本相同） ====================
map_values <- function(x, mapping) {
  as.numeric(unname(mapping[as.character(x)]))
}

add_domain_features <- function(df) {
  out <- df
  
  ordinal.maps <- list(
    income = c(
      "0 - 10k" = 5, "10k - 15k" = 12.5, "15k - 20k" = 17.5,
      "20k - 50k" = 35, "50k - 80k" = 65, "80k - 120k" = 100,
      "120k - 150k" = 135, "150k - 200k" = 175, "200k above" = 220
    ),
    whatIsYourHeightExpressItAsANumberInMetresM = c(
      "140 - 150" = 145, "150 - 155" = 152.5, "155 - 160" = 157.5,
      "160 - 165" = 162.5, "165 - 170" = 167.5, "170 - 175" = 172.5,
      "175 - 180" = 177.5, "180 - 185" = 182.5, "185 - 190" = 187.5,
      "190 above" = 195
    ),
    howOftenDoYouFeelSociallyConnectedWithYourPeersAndFriends = c(
      "Never" = 0, "Rarely" = 1, "Sometimes" = 2, "Always" = 3
    ),
    howOftenDoYouParticipateInSocialActivitiesIncludingClubsSportsV = c(
      "No" = 0, "Rarely" = 1, "At least once a month" = 2,
      "At least once a week" = 3, "More than three times a week" = 4
    ),
    doYouFeelComfortableEngagingInConversationsWithPeopleFromDiffer = c(
      "Never" = 0, "Rarely" = 1, "Sometimes" = 2, "Always" = 3
    ),
    doYouHaveASupportSystemOfFriendsAndFamilyToTurnToWhenNeeded = c(
      "No" = 0, "Yes, I have family" = 1, "Yes, I have friends" = 1,
      "Yes, I have both" = 2
    ),
    doYouFeelASenseOfPurposeAndMeaningInYourLife104 = c("No" = 0, "Yes" = 1),
    doYouFeelASenseOfPurposeAndMeaningInYourLife105 = c("No" = 0, "Yes" = 1),
    gender = c("Female" = 0, "Male" = 1, "Other" = 2),
    howDoYouReconcileSpiritualBeliefsWithScientificOrRationalThinki = c(
      "They conflict" = 0, "They are separate" = 1, "They complement each other" = 2
    )
  )
  
  for (col in names(ordinal.maps)) {
    if (col %in% names(out)) {
      out[[paste0(col, "_ord")]] <- map_values(out[[col]], ordinal.maps[[col]])
    }
  }
  
  add_mean <- function(new.col, cols) {
    cols <- intersect(cols, names(out))
    if (length(cols) > 0) {
      out[[new.col]] <<- rowMeans(out[, cols, drop = FALSE], na.rm = TRUE)
    }
  }
  
  add_mean("stress_index", c("alwaysStressed", "alwaysDepressed", "alwaysHaveDigestiveProblems"))
  add_mean(
    "self_worth_index",
    c(
      "alwaysLoveAndCareForYourself",
      "iDontFeelParticularlyPleasedWithTheWayIAm",
      "iDontThinkILookAttractive",
      "iFeelThatIAmNotEspeciallyInControlOfMyLife"
    )
  )
  add_mean(
    "social_index",
    c(
      "iHaveVeryWarmFeelingsTowardsAlmostEveryone",
      "iAlwaysHaveACheerfulEffectOnOthers",
      "iAmIntenselyInterestedInOtherPeople",
      "extremelyGoodCommunicator"
    )
  )
  add_mean(
    "life_satisfaction_index",
    c(
      "lifeIsGood", "alwaysHaveFun", "iFeelThatLifeIsVeryRewarding",
      "iAmWellSatisfiedAboutEverythingInMyLife", "iLaughALot", "iFindBeautyInSomeThings"
    )
  )
  
  positive.cols <- intersect(
    c(
      "alwaysLoveAndCareForYourself", "lifeIsGood", "alwaysHaveFun",
      "iAmWellSatisfiedAboutEverythingInMyLife", "alwaysCalm",
      "iFeelThatLifeIsVeryRewarding", "iHaveVeryWarmFeelingsTowardsAlmostEveryone",
      "iLaughALot", "iUsuallyHaveAGoodInfluenceOnEvents",
      "iFindMostThingsAmusing", "iFindBeautyInSomeThings"
    ),
    names(out)
  )
  negative.cols <- intersect(
    c(
      "alwaysStressed", "alwaysDepressed",
      "iFeelThatIAmNotEspeciallyInControlOfMyLife",
      "iDoNotThinkThatTheWorldIsAGoodPlace",
      "iDontFeelParticularlyPleasedWithTheWayIAm",
      "iRarelyWakeUpFeelingRested",
      "iAmNotParticularlyOptimisticAboutTheFuture",
      "alwaysHaveDigestiveProblems",
      "iDontThinkILookAttractive"
    ),
    names(out)
  )
  
  if (length(positive.cols) > 0) {
    out$positive_mean <- rowMeans(out[, positive.cols, drop = FALSE], na.rm = TRUE)
  }
  if (length(negative.cols) > 0) {
    out$negative_mean <- rowMeans(out[, negative.cols, drop = FALSE], na.rm = TRUE)
  }
  if (length(positive.cols) > 0 && length(negative.cols) > 0) {
    out$positive_minus_negative <- out$positive_mean - out$negative_mean
  }
  
  out
}

prepare_features <- function(train.features, test.features) {
  combined <- rbind(add_domain_features(train.features), add_domain_features(test.features))
  
  # 将所有特征转为数值（XGBoost 需要数值矩阵）
  for (col in names(combined)) {
    if (is.character(combined[[col]]) || is.factor(combined[[col]])) {
      # 类别变量转成整数因子
      combined[[col]] <- as.integer(factor(combined[[col]], levels = unique(combined[[col]])))
    } else {
      values <- suppressWarnings(as.numeric(combined[[col]]))
      med <- median(values, na.rm = TRUE)
      if (!is.finite(med)) med <- 0
      values[is.na(values)] <- med
      combined[[col]] <- values
    }
  }
  
  # 转换为矩阵（XGBoost 要求）
  x_train <- as.matrix(combined[seq_len(nrow(train.features)), , drop = FALSE])
  x_test <- as.matrix(combined[(nrow(train.features) + 1):nrow(combined), , drop = FALSE])
  
  list(x_train = x_train, x_test = x_test)
}

macro_f1 <- function(actual, predicted) {
  actual <- factor(as.integer(actual), levels = LABELS)
  predicted <- factor(as.integer(predicted), levels = LABELS)
  f1.values <- numeric(length(LABELS))
  
  for (i in seq_along(LABELS)) {
    lev <- LABELS[i]
    tp <- sum(actual == lev & predicted == lev)
    fp <- sum(actual != lev & predicted == lev)
    fn <- sum(actual == lev & predicted != lev)
    precision <- if ((tp + fp) == 0) 0 else tp / (tp + fp)
    recall <- if ((tp + fn) == 0) 0 else tp / (tp + fn)
    f1.values[i] <- if ((precision + recall) == 0) 0 else 2 * precision * recall / (precision + recall)
  }
  
  mean(f1.values)
}

make_folds <- function(y, k, seed) {
  set.seed(seed)
  y <- factor(y, levels = LABELS)
  folds <- integer(length(y))
  
  for (lev in levels(y)) {
    idx <- which(y == lev)
    folds[idx] <- sample(rep(seq_len(k), length.out = length(idx)))
  }
  
  folds
}

class_sample_weight <- function(y) {
  counts <- table(factor(y, levels = LABELS))
  weights <- length(y) / (length(LABELS) * counts)
  as.numeric(weights[as.character(y)])
}

# ==================== XGBoost 模型训练与预测 ====================
fit_xgb_regression <- function(x, target, weights, param.set, seed) {
  # 转换为 xgb.DMatrix
  dtrain <- xgb.DMatrix(data = x, label = target, weight = weights)
  
  params <- list(
    objective = "reg:squarederror",
    eval_metric = "rmse",
    max_depth = param.set$depth,
    eta = param.set$learning_rate,
    lambda = param.set$l2_leaf_reg,
    alpha = 0,
    subsample = param.set$rsm,
    colsample_bytree = param.set$rsm,
    min_child_weight = param.set$min_child_weight,  # 替代 random_strength 概念
    seed = seed,
    nthread = 2,
    verbose = 0
  )
  
  # 迭代次数
  nrounds <- param.set$iterations
  
  model <- xgb.train(params = params, data = dtrain, nrounds = nrounds, verbose = 0)
  return(model)
}

predict_xgb_regression <- function(model, x) {
  dtest <- xgb.DMatrix(data = x)
  as.numeric(predict(model, dtest))
}

run_mapped_xgb_ensemble <- function(x.train, y, mapped.y, x.test, param.sets, seeds, folds, tag) {
  oof.sum <- rep(0, length(y))
  oof.count <- rep(0, length(y))
  test.sum <- rep(0, nrow(x.test))
  total.jobs <- nrow(param.sets) * length(seeds) * folds
  job.idx <- 0
  
  for (param.idx in seq_len(nrow(param.sets))) {
    param.set <- param.sets[param.idx, ]
    for (seed in seeds) {
      fold.id <- make_folds(y, folds, seed + 7000)
      for (fold in seq_len(folds)) {
        job.idx <- job.idx + 1
        tr.idx <- which(fold.id != fold)
        va.idx <- which(fold.id == fold)
        weights <- class_sample_weight(y[tr.idx])
        
        model <- fit_xgb_regression(
          x.train[tr.idx, , drop = FALSE],
          mapped.y[tr.idx],
          weights,
          param.set,
          seed + 9000 + fold
        )
        
        va.pred <- predict_xgb_regression(model, x.train[va.idx, , drop = FALSE])
        test.pred <- predict_xgb_regression(model, x.test)
        oof.sum[va.idx] <- oof.sum[va.idx] + va.pred
        oof.count[va.idx] <- oof.count[va.idx] + 1
        test.sum <- test.sum + test.pred / folds
        
        cat(sprintf("[%s %2d/%2d] param=%s seed=%d fold=%d\n", tag, job.idx, total.jobs, param.set$name, seed, fold))
      }
    }
  }
  
  list(
    oof_score = oof.sum / pmax(oof.count, 1),
    test_score = test.sum / (nrow(param.sets) * length(seeds))
  )
}

# ==================== 分箱调优（与原脚本相同） ====================
cutpoint_predict <- function(score, cutpoints) {
  LABELS[findInterval(score, cutpoints) + 1]
}

initial_cutpoints_by_prior <- function(score, y) {
  class.prior <- prop.table(table(factor(y, levels = LABELS)))
  probs <- cumsum(as.numeric(class.prior))[seq_len(length(LABELS) - 1)]
  cuts <- as.numeric(quantile(score, probs = probs, names = FALSE, type = 8))
  for (idx in seq_along(cuts)) {
    if (idx > 1 && cuts[idx] <= cuts[idx - 1]) {
      cuts[idx] <- cuts[idx - 1] + 1e-4
    }
  }
  cuts
}

tune_cutpoints <- function(score, y, trials = CUTPOINT_TRIALS, seed = 5200) {
  set.seed(seed)
  low <- as.numeric(quantile(score, 0.01, names = FALSE, type = 8)) - 0.15
  high <- as.numeric(quantile(score, 0.99, names = FALSE, type = 8)) + 0.15
  if (!is.finite(low) || !is.finite(high) || low >= high) {
    low <- min(score, na.rm = TRUE) - 0.1
    high <- max(score, na.rm = TRUE) + 0.1
  }
  
  candidate.cuts <- list(
    initial_cutpoints_by_prior(score, y),
    as.numeric(quantile(score, probs = c(0.18, 0.35, 0.65, 0.88), names = FALSE, type = 8)),
    as.numeric(quantile(score, probs = c(0.16, 0.31, 0.70, 0.86), names = FALSE, type = 8))
  )
  
  best.cuts <- candidate.cuts[[1]]
  best.score <- -Inf
  for (cuts in candidate.cuts) {
    cuts <- sort(pmin(pmax(cuts, low), high))
    score.value <- macro_f1(y, cutpoint_predict(score, cuts))
    if (score.value > best.score) {
      best.score <- score.value
      best.cuts <- cuts
    }
  }
  
  for (trial in seq_len(trials)) {
    cuts <- sort(runif(length(LABELS) - 1, low, high))
    score.value <- macro_f1(y, cutpoint_predict(score, cuts))
    if (score.value > best.score) {
      best.score <- score.value
      best.cuts <- cuts
    }
  }
  
  step.base <- max(0.01, (high - low) / 8)
  for (step in step.base * c(1, 0.5, 0.25, 0.125, 0.0625)) {
    improved <- TRUE
    guard <- 0
    while (improved && guard < 70) {
      guard <- guard + 1
      improved <- FALSE
      for (idx in seq_along(best.cuts)) {
        for (delta in c(-step, step)) {
          cuts <- best.cuts
          lower <- if (idx == 1) low else cuts[idx - 1] + 1e-4
          upper <- if (idx == length(cuts)) high else cuts[idx + 1] - 1e-4
          cuts[idx] <- min(max(cuts[idx] + delta, lower), upper)
          score.value <- macro_f1(y, cutpoint_predict(score, cuts))
          if (score.value > best.score) {
            best.score <- score.value
            best.cuts <- cuts
            improved <- TRUE
          }
        }
      }
    }
  }
  
  list(cutpoints = best.cuts, score = best.score)
}

standardize_pair <- function(oof.score, test.score) {
  center <- mean(oof.score)
  scale <- sd(oof.score)
  if (!is.finite(scale) || scale == 0) scale <- 1
  list(oof = (oof.score - center) / scale, test = (test.score - center) / scale)
}

prediction_counts <- function(pred) {
  tab <- table(factor(pred, levels = LABELS))
  paste(names(tab), as.integer(tab), collapse = ", ")
}

write_submission <- function(path, sample.path, n.test, pred) {
  row.index <- seq_len(n.test)
  if (file.exists(sample.path)) {
    sample <- read.csv(sample.path)
    if ("RowIndex" %in% names(sample) && nrow(sample) == n.test) {
      row.index <- sample$RowIndex
    }
  }
  write.csv(
    data.frame(RowIndex = row.index, Prediction = as.integer(pred)),
    path,
    row.names = FALSE
  )
}

# ==================== 数据加载 ====================
if (!file.exists(train.path) || !file.exists(test.path)) {
  stop(paste("缺少分类训练/测试CSV文件。\n需要：", train.path, "\n", test.path))
}

train <- read.csv(train.path, stringsAsFactors = FALSE)
test <- read.csv(test.path, stringsAsFactors = FALSE)
y <- as.integer(train$alwaysAnxious)

# 特征工程（返回矩阵）
features <- prepare_features(train[, setdiff(names(train), "alwaysAnxious"), drop = FALSE], test)
x.train <- features$x_train
x.test <- features$x_test

# ==================== 模型参数（调整以适应 XGBoost） ====================
param.sets <- data.frame(
  name = c("xgb_d4_lr035", "xgb_d3_lr045"),
  depth = c(4, 3),
  iterations = c(520, 420),
  learning_rate = c(0.035, 0.045),
  l2_leaf_reg = c(6.0, 4.0),
  rsm = c(0.85, 0.90),
  min_child_weight = c(1.0, 1.0),   # 替代 random_strength
  stringsAsFactors = FALSE
)

target.maps <- list(
  linear = c("-2" = -2.0, "-1" = -1.0, "0" = 0.0, "1" = 1.0, "2" = 2.0),
  extreme_wide = c("-2" = -2.25, "-1" = -1.0, "0" = 0.0, "1" = 1.0, "2" = 2.25),
  mid_compress = c("-2" = -2.0, "-1" = -0.80, "0" = 0.0, "1" = 0.80, "2" = 2.0),
  public_asym = c("-2" = -2.20, "-1" = -1.05, "0" = 0.0, "1" = 0.90, "2" = 2.15)
)

# ==================== 主流程 ====================
cat("================ XGBoost Regression Cutpoints ================\n")
cat("x_train:", nrow(x.train), "x", ncol(x.train), "\n")
cat("x_test:", nrow(x.test), "x", ncol(x.test), "\n")
cat("class distribution:\n")
print(table(y))

summary.rows <- data.frame(
  file = character(),
  method = character(),
  oof_macro_f1 = numeric(),
  cutpoints = character(),
  test_counts = character(),
  stringsAsFactors = FALSE
)

score.bank <- list()
z.bank <- list()

add_candidate <- function(suffix, method, pred.test, oof.score, cuts) {
  path <- paste0(output.prefix, "_", suffix, ".csv")
  write_submission(path, sample.path, nrow(test), pred.test)
  summary.rows <<- rbind(
    summary.rows,
    data.frame(
      file = path,
      method = method,
      oof_macro_f1 = oof.score,
      cutpoints = paste(round(cuts, 5), collapse = ", "),
      test_counts = prediction_counts(pred.test),
      stringsAsFactors = FALSE
    )
  )
  cat("Wrote", path, "| OOF macro-F1:", round(oof.score, 6), "|", prediction_counts(pred.test), "\n")
}

for (map.name in names(target.maps)) {
  cat("\n--- XGBoost target mapping:", map.name, "---\n")
  mapped.y <- as.numeric(target.maps[[map.name]][as.character(y)])
  ens <- run_mapped_xgb_ensemble(x.train, y, mapped.y, x.test, param.sets, SEEDS, FOLDS, map.name)
  score.bank[[map.name]] <- ens
  z.bank[[map.name]] <- standardize_pair(ens$oof_score, ens$test_score)
  
  tune <- tune_cutpoints(ens$oof_score, y, CUTPOINT_TRIALS, seed = 7200 + length(score.bank))
  pred.test <- cutpoint_predict(ens$test_score, tune$cutpoints)
  add_candidate(map.name, paste("xgb target mapping", map.name), pred.test, tune$score, tune$cutpoints)
}

make_blend <- function(weights) {
  weights <- weights / sum(weights)
  names.use <- names(weights)
  oof <- rep(0, length(y))
  test.score <- rep(0, nrow(test))
  for (nm in names.use) {
    oof <- oof + weights[[nm]] * z.bank[[nm]]$oof
    test.score <- test.score + weights[[nm]] * z.bank[[nm]]$test
  }
  list(oof = oof, test = test.score)
}

blend.defs <- list(
  blend_equal_all = c(linear = 1, extreme_wide = 1, mid_compress = 1, public_asym = 1),
  blend_linear_public = c(linear = 0.55, public_asym = 0.45),
  blend_linear_extreme = c(linear = 0.65, extreme_wide = 0.35),
  blend_linear_mid = c(linear = 0.65, mid_compress = 0.35),
  blend_public_extreme = c(public_asym = 0.55, extreme_wide = 0.45),
  blend_linear_public_extreme = c(linear = 0.45, public_asym = 0.30, extreme_wide = 0.25)
)

cat("\n--- XGBoost continuous-score blends ---\n")
for (blend.name in names(blend.defs)) {
  blend <- make_blend(blend.defs[[blend.name]])
  tune <- tune_cutpoints(blend$oof, y, BLEND_CUTPOINT_TRIALS, seed = 8100 + which(names(blend.defs) == blend.name))
  pred.test <- cutpoint_predict(blend$test, tune$cutpoints)
  add_candidate(blend.name, paste("xgb z-score blend", blend.name), pred.test, tune$score, tune$cutpoints)
}

summary.rows <- summary.rows[order(summary.rows$oof_macro_f1, decreasing = TRUE), ]
write.csv(summary.rows, paste0(output.prefix, "_summary.csv"), row.names = FALSE)

cat("\nSummary written to", paste0(output.prefix, "_summary.csv"), "\n")
print(summary.rows)