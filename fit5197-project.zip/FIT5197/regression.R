packages <- c("randomForest", "xgboost", "gbm", "glmnet", "caret", "dplyr", "forecast")
for (p in packages) {
  if (!require(p, character.only = TRUE)) {
    install.packages(p, repos = "http://cran.us.r-project.org")
    library(p, character.only = TRUE)
  }
}

train <- read.csv("regression_train.csv")
test  <- read.csv("regression_test.csv")

y_raw <- train$happiness
shift <- min(y_raw) - 0.1
y_shift <- y_raw - shift
lambda <- BoxCox.lambda(y_shift)
if (lambda < 0.01 || lambda > 0.99) lambda <- 1
y_trans <- BoxCox(y_shift, lambda)
cat("Box-Cox lambda =", lambda, "\n")

trainX_raw <- train[, !names(train) %in% c("happiness")]
testX_raw  <- test

num_cols_train <- names(trainX_raw)[sapply(trainX_raw, is.numeric)]
num_cols_test  <- names(testX_raw)[sapply(testX_raw, is.numeric)]
common_num <- intersect(num_cols_train, num_cols_test)

for (col in common_num) {
  new_name <- paste0(col, "_sq")
  trainX_raw[[new_name]] <- trainX_raw[[col]]^2
  testX_raw[[new_name]]  <- testX_raw[[col]]^2
}

combined_raw <- rbind(trainX_raw, testX_raw)
dummies <- dummyVars(~ ., data = combined_raw, fullRank = TRUE)
combined_enc <- predict(dummies, newdata = combined_raw)

n_train <- nrow(trainX_raw)
trainX_enc <- combined_enc[1:n_train, ]
testX_enc  <- combined_enc[(n_train+1):nrow(combined_enc), ]

set.seed(2028)
n_folds <- 5
folds <- createFolds(y_trans, k = n_folds, list = TRUE, returnTrain = FALSE)

OOF_preds <- data.frame(rf = rep(NA, length(y_trans)),
                        xgb = rep(NA, length(y_trans)),
                        gbm = rep(NA, length(y_trans)),
                        ridge = rep(NA, length(y_trans)))
test_preds_stack <- data.frame(rf = rep(0, nrow(testX_enc)),
                               xgb = rep(0, nrow(testX_enc)),
                               gbm = rep(0, nrow(testX_enc)),
                               ridge = rep(0, nrow(testX_enc)))

for (k in 1:n_folds) {
  cat("\n===== Fold", k, "=====\n")
  idx_test <- folds[[k]]
  idx_train <- setdiff(1:nrow(trainX_enc), idx_test)
  
  X_tr <- trainX_enc[idx_train, ]
  y_tr <- y_trans[idx_train]
  X_te <- trainX_enc[idx_test, ]
  y_te <- y_trans[idx_test]
  
  p <- ncol(X_tr)
  mtry_try <- round(c(p/3, p/2, 2*p/3))
  mtry_try <- unique(pmax(1, pmin(mtry_try, p)))
  best_rmse <- Inf
  best_rf <- NULL
  for (mt in mtry_try) {
    rf_tmp <- randomForest(x = X_tr, y = y_tr, mtry = mt, ntree = 500, importance = FALSE)
    pred_tmp <- predict(rf_tmp, X_te)
    rmse_tmp <- sqrt(mean((y_te - pred_tmp)^2))
    if (rmse_tmp < best_rmse) {
      best_rmse <- rmse_tmp
      best_rf <- rf_tmp
    }
  }
  OOF_preds$rf[idx_test] <- predict(best_rf, X_te)
  test_preds_stack$rf <- test_preds_stack$rf + predict(best_rf, testX_enc)
  cat("  RF best mtry =", best_rf$mtry, " | OOF RMSE =", round(best_rmse, 4), "\n")
  
  dtrain <- xgb.DMatrix(data = as.matrix(X_tr), label = y_tr)
  dtest  <- xgb.DMatrix(data = as.matrix(X_te))
  param_grid <- expand.grid(eta = c(0.01, 0.05),
                            max_depth = c(4, 6),
                            nrounds = c(200, 400))
  best_rmse_xgb <- Inf
  best_xgb <- NULL
  for (i in 1:nrow(param_grid)) {
    params <- list(objective = "reg:squarederror",
                   eta = param_grid$eta[i],
                   max_depth = param_grid$max_depth[i])
    xgb_tmp <- xgb.train(params = params, data = dtrain, nrounds = param_grid$nrounds[i],
                         verbose = 0, early_stopping_rounds = 20, watchlist = list(train=dtrain))
    pred_tmp <- predict(xgb_tmp, dtest)
    rmse_tmp <- sqrt(mean((y_te - pred_tmp)^2))
    if (rmse_tmp < best_rmse_xgb) {
      best_rmse_xgb <- rmse_tmp
      best_xgb <- xgb_tmp
    }
  }
  OOF_preds$xgb[idx_test] <- predict(best_xgb, dtest)
  test_preds_stack$xgb <- test_preds_stack$xgb + predict(best_xgb, as.matrix(testX_enc))
  cat("  XGB best: eta=", best_xgb$params$eta, " depth=", best_xgb$params$max_depth,
      " rounds=", best_xgb$niter, " | OOF RMSE =", round(best_rmse_xgb, 4), "\n")
  
  gbm_grid <- expand.grid(interaction.depth = c(3, 5),
                          n.trees = c(300, 500),
                          shrinkage = c(0.05, 0.1),
                          n.minobsinnode = 10)
  best_rmse_gbm <- Inf
  best_gbm <- NULL
  for (j in 1:nrow(gbm_grid)) {
    gbm_tmp <- gbm(y_tr ~ ., data = as.data.frame(X_tr),
                   distribution = "gaussian",
                   n.trees = gbm_grid$n.trees[j],
                   interaction.depth = gbm_grid$interaction.depth[j],
                   shrinkage = gbm_grid$shrinkage[j],
                   verbose = FALSE)
    pred_tmp <- predict(gbm_tmp, newdata = as.data.frame(X_te), n.trees = gbm_grid$n.trees[j])
    rmse_tmp <- sqrt(mean((y_te - pred_tmp)^2))
    if (rmse_tmp < best_rmse_gbm) {
      best_rmse_gbm <- rmse_tmp
      best_gbm <- gbm_tmp
      best_gbm_n.trees <- gbm_grid$n.trees[j]
    }
  }
  OOF_preds$gbm[idx_test] <- predict(best_gbm, newdata = as.data.frame(X_te), n.trees = best_gbm_n.trees)
  test_preds_stack$gbm <- test_preds_stack$gbm + predict(best_gbm, newdata = as.data.frame(testX_enc), n.trees = best_gbm_n.trees)
  cat("  GBM best: depth=", best_gbm$interaction.depth, " shrinkage=", best_gbm$shrinkage,
      " n.trees=", best_gbm_n.trees, " | OOF RMSE =", round(best_rmse_gbm, 4), "\n")
  
  ridge_cv <- cv.glmnet(x = as.matrix(X_tr), y = y_tr, alpha = 0, nfolds = 5)
  ridge_fit <- glmnet(x = as.matrix(X_tr), y = y_tr, alpha = 0, lambda = ridge_cv$lambda.min)
  pred_ridge <- predict(ridge_fit, newx = as.matrix(X_te))[,1]
  OOF_preds$ridge[idx_test] <- pred_ridge
  test_preds_stack$ridge <- test_preds_stack$ridge + predict(ridge_fit, newx = as.matrix(testX_enc))[,1]
  cat("  Ridge lambda.min =", round(ridge_cv$lambda.min, 4), " | OOF RMSE =", round(sqrt(mean((y_te - pred_ridge)^2)), 4), "\n")
}

test_preds_stack <- test_preds_stack / n_folds
meta_data <- as.data.frame(OOF_preds)
meta_model <- lm(y_trans ~ ., data = meta_data)
print(summary(meta_model))

final_pred_trans <- predict(meta_model, newdata = test_preds_stack)
final_pred <- InvBoxCox(final_pred_trans, lambda) + shift

submission <- data.frame(RowIndex = 1:length(final_pred), Prediction = final_pred)
write.csv(submission, "RegressionPredictLabel_stacking.csv", row.names = FALSE)