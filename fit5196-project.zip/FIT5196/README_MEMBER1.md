# FIT5196 A1 Group029——成员1交接说明

## 当前状态

成员1负责的结构化解析、`customers`、`products`、source-to-target mapping和验证工作已经完成并实际运行。基于官方solution模板制作的工作Notebook可以从上到下运行，并重新生成两张候选CSV。

这只是成员1的工作组件，不是包含六张表的最终小组提交版本。

## 已完成内容

- 转换前核对manifest中记录的文件哈希值。
- 使用JSON/XML结构化解析器检查两个原始数据源的主要结构。
- 从JSON路径`$.customerProfiles[]`生成`customers`表。
- 从XML路径`/OperationsExport/ProductCatalogue/Product`生成`products`表。
- 按数据字典统一日期、货币、数值、布尔值和叙述文本格式。
- 在官方111行mapping模板中完成20个customer字段和21个product字段，共41行。
- 执行稳定的`VAL-...`验证，包括schema、数据类型、缺失值、主键、外键、行数变化、数值范围、日期、时间逻辑和文本检查。
- 导出两张候选CSV，并重新读取CSV检查导出前后是否一致。
- 运行官方提供的18个public text test cases，以及额外的边界值、缺失值和多语言测试。

## 主要交接文件

- `notebooks/Group029_member1_official_working.ipynb`
  - 基于官方solution模板制作并执行的成员工作副本。
  - 24/24个代码单元已执行，没有代码错误输出。
- `src/group029_member1.py`
  - 可复用的customers/products转换与验证代码。
- `src/Group029_text_functions.py`
  - 作业要求的六个纯文本处理函数。
  - 成员1在产品描述处理中调用了`clean_narrative_text()`。
- `mapping/Group029_source_to_target_mapping_member1.csv`
  - 保留官方111行及原始顺序。
  - 已填写成员1负责的41行，其余70行保持空白，等待其他成员合并。
- `outputs/member1/Group029_customers_standardised.csv`
  - 500行、20列。
- `outputs/member1/Group029_products_standardised.csv`
  - 1000行、21列。
- `tests/test_group029_member1.py`
  - customers/products转换和验证测试。
- `tests/test_group029_text_functions.py`
  - 六个文本函数的官方案例和补充边界测试。
- `tests/test_group029_mapping.py`
  - 检查mapping行数、顺序、填写范围和来源路径。
- `templates/A1_public_text_test_cases.csv`
  - 文本函数测试依赖的官方测试案例。
- `templates/A1_source_to_target_mapping_template.csv`
  - mapping测试依赖的官方模板。

早期的`mapping/Group029_member1_mapping_draft.json`只是审计草稿，已经被正式格式的mapping CSV替代，不需要用于合并。

## 运行方法

将Group029原始数据包解压为项目根目录下的`raw_package`文件夹，然后在项目根目录使用FIT5196 Python 3.12环境运行：

```powershell
python '.\src\group029_member1.py' '.'
python -m unittest discover -s '.\tests' -v
python -m jupyter nbconvert --execute --to notebook --inplace '.\notebooks\Group029_member1_official_working.ipynb' --ExecutePreprocessor.kernel_name=fit5196-py312 --ExecutePreprocessor.timeout=180
```

Notebook、源代码和测试均使用相对路径，不包含成员个人电脑的绝对路径。

## 数据来源和关键处理决定

- JSON中的`customerProfiles`作为客户主数据；两个订单数据源中的customer ID只用于检查引用覆盖情况。
- XML中的`ProductCatalogue`作为产品主数据；两个购物车来源中的product ID只用于检查引用覆盖情况。
- XML产品发布日期严格按`DD/MM/YYYY`解析，最终输出为`YYYY-MM-DD`，并检查解析年份是否与`Launch_Year`一致。
- 邮编和各类ID保留为字符串；`Y/N`标记转换为Python布尔值。
- 产品描述依次执行HTML实体解码、Unicode NFC标准化、限定范围的正则清洗、emoji删除、空白合并和小写转换；缺失文本输出字面值`NaN`。
- Group029的实际行数在运行时从原始数据计算，没有把观察到的行数硬编码成固定答案。

## 其他成员需要继续完成的工作

- 将成员1的已执行代码单元合并到最终的`Group029_solution.ipynb`。
- 完成`orders`、`order_items`、`deliveries`和`product_reviews`四张表。
- 完成跨JSON/XML来源的重叠数据核对、冲突处理和订单金额计算。
- 负责reviews的成员应检查并复用`Group029_text_functions.py`中的六个共享函数，避免重复实现或出现版本冲突。
- 最终小组运行必须完成全部111行mapping，并导出全部六张CSV。
- 等六张输出表冻结且表间join cardinality验证完成后，再进行最终EDA、findings和ML问题设计。
- 本次交接没有处理AI declaration、对话索引或对话导出；这些内容由小组在最终提交前统一完成。
