# FIT5196 A1 Group029 - 成员2交接说明

## 1. 本次完成范围

本交接在成员1成果上继续完成截图中成员2的职责：

- 结构化解析 JSON/XML 中的 `orders` 和 `order_items`；
- 统一 ID、时间戳、货币、百分比、布尔值与字符串缺失哨兵；
- 复用成员1交付的 `Group029_text_functions.py` 处理 `customer_note_clean` 和 `promo_code`；
- 在源内重复和跨源重叠记录之间执行字段级比较；
- 按规范重新计算 `line_revenue`、`order_price`、`tax_amount` 和 `order_total`；
- 对接成员1的 `customers`、`products` 表做真实主外键检查；
- 完成 orders/order_items 的 29 行 source-to-target mapping；
- 生成并执行成员1+2集成 solution notebook；
- 生成并执行成员2 EDA notebook、Figure 3、Figure 4、3条 finding 草稿和1个 ML question 草稿；
- 新增成员2单元测试/集成测试，并重新运行成员1及共享文本函数测试。
- 修复必填 ID 的字面值 `NaN` 漏检：解析、validation、CSV 导出三层均会阻止空值及 `NaN`/`NULL`/`None`/`<NA>` 等 null-like 文本进入必填 ID。

这仍然不是最终六表提交版本。`deliveries` 和 `product_reviews` 需要其他成员继续集成。

## 2. 主要文件

- `src/group029_member2.py`
  - 成员2完整可复用流水线。
- `tests/test_group029_member2.py`
  - 标准化、冲突检测、金额计算、主外键、CSV round trip、mapping 和 EDA 分母测试。
- `mapping/Group029_source_to_target_mapping_member1_member2.csv`
  - 保留成员1的41行，新增成员2的29行；当前111行中70行已完成。
- `notebooks/Group029_member1_member2_official_working.ipynb`
  - 基于成员1官方模板工作副本集成成员2代码；24/24个代码单元已执行，无错误输出。
- `notebooks/Group029_member2_EDA_working.ipynb`
  - 只包含成员2负责的 Figure 3、Figure 4、findings 和 ML question；4/4个代码单元已执行，无错误输出。
- `outputs/member2/Group029_orders_standardised.csv`
  - 5,000行、23列。
- `outputs/member2/Group029_order_items_standardised.csv`
  - 15,706行、6列。
- `outputs/member2/Group029_member2_validation.csv`
  - 22项稳定 `VAL-...` 检查，当前全部 PASS。
- `outputs/member2/figures/Figure3_order_value_by_channel_and_coupon.png`
- `outputs/member2/figures/Figure4_monthly_order_activity_and_revenue.png`
- `outputs/member2/figures/member2_eda_summary.json`
  - Figure 3/4 的问题、观察单位、分母和底层统计量。
- `tools/build_member2_notebooks.py`
  - 从成员1/官方模板可重复构建两个成员2工作 notebook。
- `tools/acceptance_check.py`
  - 对实际生成的 CSV、mapping、validation、图片及 notebook 执行最终只读验收。

## 3. 如何运行

在项目根目录运行完整成员2流水线：

```powershell
python '.\src\group029_member2.py' '.' --make-figures
```

交接 ZIP 按 Moodle 规则不包含 raw JSON/XML。首次运行前，需要把课程提供的完整 `raw_package/` 文件夹放在解压后的项目根目录；ZIP 已包含成员1原始 mapping、成员1 notebook 工作底稿和 EDA 模板，因此不再依赖交接者电脑上的其他目录。

如果当前 Python 环境没有 matplotlib/seaborn，可先不生成图：

```powershell
python '.\src\group029_member2.py' '.'
```

运行全部测试：

```powershell
python -m unittest discover -s '.\tests' -v
```

重新构建并执行 notebooks：

```powershell
python '.\tools\build_member2_notebooks.py'
python -m jupyter nbconvert --execute --to notebook --inplace `
  '.\notebooks\Group029_member1_member2_official_working.ipynb' `
  --ExecutePreprocessor.kernel_name=python3 `
  --ExecutePreprocessor.timeout=180
python -m jupyter nbconvert --execute --to notebook --inplace `
  '.\notebooks\Group029_member2_EDA_working.ipynb' `
  --ExecutePreprocessor.kernel_name=python3 `
  --ExecutePreprocessor.timeout=180
python '.\tools\acceptance_check.py' '.'
```

## 4. 代码流程和含义

### 4.1 `build_json_transactions()` / `build_xml_transactions()`

这两个函数只使用 JSON/XML 结构化解析器访问：

- JSON：`$.orders[].header` 和 `$.orders[].shoppingCart[]`
- XML：`/OperationsExport/Orders/Order/Header` 和 `Shopping_Cart/Item`

它们将两套字段名映射到相同目标名，例如：

- `orderID` / `Order_ID` -> `order_id`
- `deliveryCharges` / `Delivery_Charges` -> `delivery_charges`
- `expeditedDelivery` / `Expedited_Delivery` -> `expedited_delivery`

XML 中的 `AUD 1,234.56`、`15%`、`Y/N` 被显式转换；JSON 中的原生 boolean 必须保持 boolean，不能使用字符串 truthiness。

### 4.1.1 必填 ID 的 `NaN` 修复

`_required_string()` 现在把真实缺失值、空白字符串以及大小写不同的 `NaN`、`NULL`、`None`、`<NA>` 都视为语义缺失并立即抛出错误。`_semantic_missing_mask()` 在 DataFrame validation 中重复执行同一规则，`write_outputs()` 在落盘前再检查以下六个必填 ID：

- `orders.order_id`
- `orders.source_system_record_id`
- `orders.customer_id`
- `order_items.order_item_id`
- `order_items.order_id`
- `order_items.product_id`

可选字段 `coupon_code` 和 `promo_code` 仍按规范允许使用字面值 `NaN`。测试中会故意把一个 `orders.order_id` 改成 `"NaN"`，并要求 validation 必须失败，以证明这不是仅对当前数据做的表面检查。

### 4.2 为什么保留 `_reported_...` helper fields

源数据包含 `Line_Revenue`、`Order_Price`、`Tax_Amount` 和 `Order_Total`，但规范要求独立重算。因此代码将源值保存在：

- `_reported_line_revenue`
- `_reported_order_price`
- `_reported_tax_amount`
- `_reported_order_total`

这些字段只用于 validation，不会进入提交 CSV。

### 4.3 `find_conflicts()`

该函数在 `drop_duplicates()` 之前按 `order_id` 或 `order_item_id` 分组，比较所有标准化目标字段：

- 字符串、布尔值要求完全一致；
- 金额使用字段级绝对容差；
- 冲突证据会记录业务键、字段、来源和观察值；
- 如果存在冲突，流水线停止导出，避免静默 JSON-over-XML 或 XML-over-JSON 优先。

当前数据观察结果：

| Entity | JSON rows | XML rows | Cross-source overlap | Canonical rows | Field conflicts |
|---|---:|---:|---:|---:|---:|
| orders | 2,818 | 2,818 | 500 | 5,000 | 0 |
| order_items | 8,801 | 8,958 | 1,595 | 15,706 | 0 |

这些数字由运行时计算，只作为验证证据，不是硬编码转换条件。

### 4.4 `_canonical_rows()`

只有在 `find_conflicts()` 已证明重复记录的目标值一致后，该函数才按业务主键保留一行。稳定排序只用于保证同一输入每次得到同一输出，不代表选择某一个来源作为业务权威。

### 4.5 金额计算

计算顺序严格对应作业规范：

```python
line_revenue = round(quantity * unit_price, 2)
order_price = round(sum(line_revenue), 2)
tax_amount = round(order_price / 11, 2)
order_total = round(
    order_price * (1 - coupon_discount / 100)
    + delivery_charges,
    2,
)
```

`tax_amount` 是商品价格中已经包含的 GST，只单独报告，不能再次加到 `order_total`。

### 4.6 `validate_member2_tables()`

该函数产生与成员1一致的 validation register 格式，覆盖：

- schema、列顺序与数据类型；
- required/nullable 字段和字面值 `NaN`；
- 两张表的主键；
- item -> order、item -> product、order -> customer 外键；
- 源内重复、跨源重叠和 canonical union；
- 字段级冲突；
- line/order/GST/total 金额对账；
- 时间戳格式；
- 数值范围、坐标范围；
- 客户备注清洗和 promo 提取。

当前22项检查全部 PASS。源报告金额与重算金额的最大浮点观察差约为 `0.010000000000218279`，验证实现使用规范的绝对容差 `0.01` 并增加极小浮点 epsilon，避免二进制浮点表现导致边界值误判。

## 5. Figure 3 和 Figure 4

### Figure 3

问题：不同销售渠道中，使用/未使用优惠券的订单金额分布是否不同？

- 观察单位：一个 canonical order
- 分母：全部5,000个订单
- 表：`orders`
- join：无
- 图形：按渠道与 coupon use 分组的箱线图
- 限制：`order_total` 是折后金额；coupon 分配不是随机实验；不能做因果解释

### Figure 4

问题：2018年月度订单数和收入如何变化？

- 观察单位：canonical order，汇总至 calendar month
- 分母：全部5,000个订单
- 表：`orders`
- join：无
- 图形：上下两个协调折线子图，分别展示 order count 和 revenue
- 限制：只有一年数据；月份天数不同；不能称为稳定季节性

## 6. 三条 findings 和一个 ML question

EDA notebook 已写入三个候选 finding：

1. 订单数最高月份与收入最高月份不同，交易量并不能单独解释收入。
2. 三个渠道的订单金额分布高度重叠，channel alone 的业务区分度可能有限。
3. coupon 订单的折后中位金额较低，但存在折扣机械关系与选择偏差，不能解释为 coupon 导致消费降低。

成员2建议的 ML question 是：按 `week × sales_channel` 预测下一周订单数，用于短期履约排班。建议 expanding-window 时间验证，指标使用 MAE/WAPE，并明确只有一年历史、缺少活动/库存字段和时间泄漏等风险。

## 7. 与成员1的接口及小修正

成员2没有改写成员1的 customers/products 转换。只对成员1 `collect_reference_ids()` 的两个结构路径做了必要修正：

- JSON customer ID 位于 `order["header"]["customerID"]`；
- XML customer ID 位于 `./Header/Customer_ID`。

原代码从订单根节点取 customer ID，会得到空引用集合，使 customer FK 检查形式上通过但没有实际覆盖。修正后，成员1与成员2的外键测试都使用真实订单引用。

## 8. 最终小组合并仍需完成

- 集成 `deliveries` 与 `product_reviews`；
- 将当前70行 mapping 与剩余41行合并为完整111行；
- 最终 solution notebook 导出六张 CSV 到统一 `outputs/`；
- 最终 EDA 必须有6-8张 assessed figures，覆盖至少四张表和至少两个正确 join；
- 最终报告必须正好10条 findings 和5个 ML questions；
- 执行最终 Restart and Run All；
- 不要将 raw JSON/XML 放入最终 Moodle ZIP；
- 完成 AI declaration、英文 AI index 和完整对话导出。
