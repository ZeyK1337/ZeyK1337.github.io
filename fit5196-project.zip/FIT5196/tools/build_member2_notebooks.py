"""Build member-2 working notebooks from the supplied official-template copies."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _source_lines(source: str) -> list[str]:
    return source.strip("\n").splitlines(keepends=True)


def _set_cell(notebook: dict, one_based_index: int, source: str) -> None:
    notebook["cells"][one_based_index - 1]["source"] = _source_lines(source)
    if notebook["cells"][one_based_index - 1]["cell_type"] == "code":
        notebook["cells"][one_based_index - 1]["execution_count"] = None
        notebook["cells"][one_based_index - 1]["outputs"] = []


def build_solution_notebook() -> Path:
    source_path = (
        PROJECT_ROOT / "notebooks" / "Group029_member1_official_working.ipynb"
    )
    notebook = json.loads(source_path.read_text(encoding="utf-8"))

    _set_cell(
        notebook,
        1,
        """
# FIT5196 Assessment 1 - Group029 Members 1-2 Integrated Working Copy

**Scope:** member 1 customers/products plus member 2 orders/order_items.

This is a tested handoff component, not the final six-table group submission.
Members responsible for deliveries and product_reviews must still integrate their
sections before the final Restart and Run All.
""",
    )
    _set_cell(
        notebook,
        3,
        """
from pathlib import Path

GROUP_ID = "Group029"

PROJECT_ROOT = Path.cwd().resolve()
if PROJECT_ROOT.name == "notebooks":
    PROJECT_ROOT = PROJECT_ROOT.parent
if not (PROJECT_ROOT / "raw_package").exists():
    raise FileNotFoundError("Run from the Group029 project root or its notebooks folder.")

INPUT_DIR = PROJECT_ROOT / "raw_package" / "raw_input"
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "member1_member2"
TEMPLATE_DIR = PROJECT_ROOT / "templates"
MAPPING_PATH = PROJECT_ROOT / "mapping" / "Group029_source_to_target_mapping_member1_member2.csv"
SRC_DIR = PROJECT_ROOT / "src"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

JSON_PATH = INPUT_DIR / f"{GROUP_ID}_commerce.json"
XML_PATH = INPUT_DIR / f"{GROUP_ID}_operations.xml"
DATA_DICTIONARY_PATH = PROJECT_ROOT / "raw_package" / "public_data_dictionary.csv"
PUBLIC_TEXT_CASES_PATH = TEMPLATE_DIR / "A1_public_text_test_cases.csv"

for required_path in [JSON_PATH, XML_PATH, DATA_DICTIONARY_PATH, PUBLIC_TEXT_CASES_PATH, MAPPING_PATH]:
    if not required_path.exists():
        raise FileNotFoundError(required_path)

print({
    "group_id": GROUP_ID,
    "project_root": ".",
    "input_dir": str(INPUT_DIR.relative_to(PROJECT_ROOT)),
    "output_dir": str(OUTPUT_DIR.relative_to(PROJECT_ROOT)),
})
""",
    )
    _set_cell(
        notebook,
        5,
        """
import json
import platform
import sys
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import pandas as pd
from IPython.display import display

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from Group029_text_functions import (
    build_latin_analysis,
    clean_narrative_text,
    contains_non_latin_script,
    extract_order_reference,
    extract_product_sku,
    extract_promo_code,
)
from group029_member1 import (
    CUSTOMER_COLUMNS,
    PRODUCT_COLUMNS,
    build_customers,
    build_products,
    collect_reference_ids,
    load_json_records,
    load_xml_root,
    sha256_file,
    validate_member1_tables,
    verify_manifest,
    write_outputs as write_member1_outputs,
)
from group029_member2 import (
    ORDER_COLUMNS,
    ORDER_ITEM_COLUMNS,
    REQUIRED_IDENTIFIER_COLUMNS,
    _semantic_missing_mask,
    build_member2_tables,
    validate_member2_tables,
    write_outputs as write_member2_outputs,
)

environment = {
    "python": platform.python_version(),
    "pandas": pd.__version__,
    "kernel_executable_name": Path(sys.executable).name,
}
environment
""",
    )
    _set_cell(
        notebook,
        11,
        """
### 1.3 Source comparison and assumptions

Orders occur in both sources with different field names and representations.
They are standardised independently, compared field by field by business key,
and only then collapsed to canonical rows. Reported arithmetic is treated as
validation evidence; submitted arithmetic is independently recomputed.
""",
    )
    _set_cell(
        notebook,
        12,
        """
source_decisions = pd.DataFrame([
    {
        "target_or_issue": "customers",
        "JSON evidence": "$.customerProfiles[] contains the 20 published customer attributes",
        "XML evidence": "orders contain customer references but no customer master",
        "decision": "JSON customerProfiles is the master; order IDs are referential checks only",
    },
    {
        "target_or_issue": "products",
        "JSON evidence": "shoppingCart contains product references but no product master",
        "XML evidence": "ProductCatalogue/Product contains the 21 published product attributes",
        "decision": "XML ProductCatalogue is the master; cart IDs are referential checks only",
    },
    {
        "target_or_issue": "orders and order_items",
        "JSON evidence": "$.orders[].header plus repeated $.orders[].shoppingCart[]",
        "XML evidence": "/OperationsExport/Orders/Order/Header plus repeated Shopping_Cart/Item",
        "decision": "standardise each source, compare by order_id/order_item_id, stop on conflict, then retain one canonical row",
    },
    {
        "target_or_issue": "dates, flags and money",
        "JSON evidence": "ISO timestamps, native booleans and typed numerics",
        "XML evidence": "DD/MM/YYYY timestamps, Y/N flags, AUD labels, commas and percent signs",
        "decision": "parse exact source formats; emit published target formats and typed values",
    },
    {
        "target_or_issue": "order arithmetic",
        "JSON evidence": "reported line/order/GST/total values",
        "XML evidence": "reported line/order/GST/total values with AUD formatting",
        "decision": "recompute from canonical quantity/unit_price in the published sequence; use reported fields only for 0.01-tolerance validation",
    },
])
display(source_decisions)
""",
    )
    _set_cell(
        notebook,
        14,
        """
mapping = pd.read_csv(MAPPING_PATH, keep_default_na=False, dtype=str)
integrated_mapping = mapping[
    mapping["output_table"].isin(["customers", "products", "orders", "order_items"])
].copy()
required_mapping_columns = [
    "source_format",
    "transformation_or_derivation",
    "overlap_or_conflict_rule",
    "notebook_evidence",
]

assert len(mapping) == 111
assert len(integrated_mapping) == 70
assert integrated_mapping["mapping_id"].str.startswith("MAP-").all()
assert integrated_mapping[required_mapping_columns].ne("").all().all()

mapping_status = integrated_mapping.groupby("output_table", as_index=False).agg(
    completed_rows=("mapping_id", "size"),
    first_mapping_id=("mapping_id", "first"),
    last_mapping_id=("mapping_id", "last"),
)
display(mapping_status)
display(integrated_mapping[integrated_mapping["output_table"].isin(["orders", "order_items"])].head(8))
""",
    )
    _set_cell(notebook, 21, "### 4.1 `orders`")
    _set_cell(
        notebook,
        22,
        """
member2_tables = build_member2_tables(json_data, xml_root)
orders = member2_tables["orders"]

assert orders.columns.tolist() == ORDER_COLUMNS
assert orders["order_id"].is_unique
for required_id in REQUIRED_IDENTIFIER_COLUMNS["orders"]:
    assert not _semantic_missing_mask(orders[required_id]).any(), required_id
display(member2_tables["source_profile"])
display(orders.head())
""",
    )
    _set_cell(notebook, 23, "### 4.2 `order_items`")
    _set_cell(
        notebook,
        24,
        """
order_items = member2_tables["order_items"]

assert order_items.columns.tolist() == ORDER_ITEM_COLUMNS
assert order_items["order_item_id"].is_unique
for required_id in REQUIRED_IDENTIFIER_COLUMNS["order_items"]:
    assert not _semantic_missing_mask(order_items[required_id]).any(), required_id
display(order_items.head())
""",
    )
    _set_cell(
        notebook,
        33,
        """
## 5. Reconcile overlap and verify relationships

The transaction sources are compared only after target normalisation. The
conflict tables identify business key, target field, sources and observed
values. Canonical selection occurs only when these tables are empty.
""",
    )
    _set_cell(
        notebook,
        34,
        """
reference_ids = collect_reference_ids(json_data, xml_root)
source_counts = {
    "customers_input": len(json_data["customerProfiles"]),
    "products_input": len(xml_root.findall("./ProductCatalogue/Product")),
}

reconciliation_evidence = member2_tables["source_profile"].copy()
reconciliation_evidence["field_conflicts"] = [
    len(member2_tables["order_conflicts"]),
    len(member2_tables["item_conflicts"]),
]
assert reconciliation_evidence["field_conflicts"].eq(0).all()
display(reconciliation_evidence)
""",
    )
    _set_cell(
        notebook,
        37,
        """
member1_validation = validate_member1_tables(
    customers,
    products,
    reference_ids,
    source_counts=source_counts,
)
member2_validation = validate_member2_tables(
    member2_tables,
    customers,
    products,
)
validation = pd.concat(
    [member1_validation, member2_validation], ignore_index=True
)
schema_checks = validation[validation["area"].isin(["schema", "missingness"])]
assert validation["status"].eq("PASS").all()
display(schema_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        40,
        """
key_checks = validation[validation["area"].isin(["keys", "relationships"])]
display(key_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        41,
        """
The relationship checks include real anti-joins from canonical orders/items to
member-1 customers/products. They also verify every item resolves to an order.
""",
    )
    _set_cell(
        notebook,
        43,
        """
flow_checks = validation[validation["area"].eq("flow")]
display(flow_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        44,
        """
The observed source counts, unique-key counts and overlap counts are calculated
from the allocated files. They are evidence, not hard-coded pipeline inputs.
""",
    )
    _set_cell(
        notebook,
        45,
        "### 6.4 Arithmetic checks (`VAL-ARITH-...`)",
    )
    _set_cell(
        notebook,
        46,
        """
arithmetic_checks = validation[validation["area"].eq("arithmetic")]
display(arithmetic_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        47,
        """
The checks independently recompute line revenue, order price, included GST and
the discounted-plus-delivery total. Source-reported monetary values are compared
with the required absolute tolerance of 0.01.
""",
    )
    _set_cell(
        notebook,
        49,
        """
temporal_checks = validation[
    validation["validation_id"].str.startswith(("VAL-TIME-", "VAL-DATE-"))
]
display(temporal_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        52,
        """
text_checks = validation[validation["area"].eq("text")]
display(text_checks.drop(columns="passed"))
""",
    )
    _set_cell(
        notebook,
        53,
        """
The order customer note and promotion code reuse the same published text module
tested in Section 3; no competing member-specific text implementation is used.
""",
    )
    _set_cell(
        notebook,
        55,
        """
literal_nan_check = pd.DataFrame([
    {
        "field": "orders.coupon_code",
        "literal_NaN_count": int(orders["coupon_code"].eq("NaN").sum()),
        "pandas_missing_count": int(orders["coupon_code"].isna().sum()),
        "empty_string_count": int(orders["coupon_code"].eq("").sum()),
    },
    {
        "field": "orders.promo_code",
        "literal_NaN_count": int(orders["promo_code"].eq("NaN").sum()),
        "pandas_missing_count": int(orders["promo_code"].isna().sum()),
        "empty_string_count": int(orders["promo_code"].eq("").sum()),
    },
])
assert literal_nan_check["pandas_missing_count"].eq(0).all()
assert literal_nan_check["empty_string_count"].eq(0).all()
display(literal_nan_check)
""",
    )
    _set_cell(
        notebook,
        56,
        """
## 7. Export member-1/member-2 CSV candidates

This integrated working copy exports customers, products, orders and order_items
to one shared candidate directory. Deliveries and product_reviews remain pending.
""",
    )
    _set_cell(
        notebook,
        57,
        """
customers_path, products_path = write_member1_outputs(customers, products, OUTPUT_DIR)
orders_path, items_path, member2_validation_path = write_member2_outputs(
    orders, order_items, member2_validation, OUTPUT_DIR
)

customers_round_trip = pd.read_csv(
    customers_path, keep_default_na=False,
    dtype={"customer_id": "string", "home_postcode": "string"},
)
products_round_trip = pd.read_csv(
    products_path, keep_default_na=False,
    dtype={"product_id": "string", "product_sku": "string"},
)
orders_round_trip = pd.read_csv(
    orders_path, keep_default_na=False,
    dtype={"order_id": "string", "customer_id": "string", "coupon_code": "string", "promo_code": "string"},
)
items_round_trip = pd.read_csv(
    items_path, keep_default_na=False,
    dtype={"order_item_id": "string", "order_id": "string", "product_id": "string"},
)

assert customers_round_trip.columns.tolist() == CUSTOMER_COLUMNS
assert products_round_trip.columns.tolist() == PRODUCT_COLUMNS
assert orders_round_trip.columns.tolist() == ORDER_COLUMNS
assert items_round_trip.columns.tolist() == ORDER_ITEM_COLUMNS
assert orders_round_trip["coupon_code"].tolist() == orders["coupon_code"].tolist()

export_summary = pd.DataFrame([
    {"table": "customers", "rows": len(customers_round_trip), "columns": len(CUSTOMER_COLUMNS), "relative_path": str(customers_path.relative_to(PROJECT_ROOT))},
    {"table": "products", "rows": len(products_round_trip), "columns": len(PRODUCT_COLUMNS), "relative_path": str(products_path.relative_to(PROJECT_ROOT))},
    {"table": "orders", "rows": len(orders_round_trip), "columns": len(ORDER_COLUMNS), "relative_path": str(orders_path.relative_to(PROJECT_ROOT))},
    {"table": "order_items", "rows": len(items_round_trip), "columns": len(ORDER_ITEM_COLUMNS), "relative_path": str(items_path.relative_to(PROJECT_ROOT))},
])
display(export_summary)
""",
    )
    _set_cell(
        notebook,
        59,
        """
reproducibility_record = pd.DataFrame([{
    "group_id": GROUP_ID,
    "run_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "python": platform.python_version(),
    "pandas": pd.__version__,
    "manifest_files_verified": int(manifest_audit["hash_matches"].sum()),
    "member1_member2_mapping_rows_complete": len(integrated_mapping),
    "validation_checks_passed": int(validation["status"].eq("PASS").sum()),
    "validation_checks_failed": int(validation["status"].eq("FAIL").sum()),
    "public_text_cases_passed": int(public_results["status"].eq("PASS").sum()),
    "orders_csv_sha256": sha256_file(orders_path),
    "order_items_csv_sha256": sha256_file(items_path),
    "members_1_2_scope_complete": True,
    "final_six_table_group_integration_complete": False,
}])
assert reproducibility_record.loc[0, "validation_checks_failed"] == 0
display(reproducibility_record.T)
""",
    )

    output_path = (
        PROJECT_ROOT
        / "notebooks"
        / "Group029_member1_member2_official_working.ipynb"
    )
    output_path.write_text(
        json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    return output_path


def build_eda_notebook() -> Path:
    template_candidates = [
        PROJECT_ROOT / "templates" / "A1_EDA_template.ipynb",
        PROJECT_ROOT.parents[1]
        / "work"
        / "templates_review"
        / "templates"
        / "A1_EDA_template.ipynb",
    ]
    template_path = next((path for path in template_candidates if path.exists()), None)
    if template_path is None:
        raise FileNotFoundError("A1_EDA_template.ipynb was not found")
    notebook = json.loads(template_path.read_text(encoding="utf-8"))

    _set_cell(
        notebook,
        1,
        """
# FIT5196 Assessment 1 - Group029 Member 2 EDA Working Copy

**Scope:** Figure 3, Figure 4, three draft findings and one draft ML question.

This notebook loads only the submitted-style transaction CSVs; it does not rerun
a hidden cleaning pipeline.
""",
    )
    _set_cell(
        notebook,
        3,
        """
from pathlib import Path

GROUP_ID = "Group029"
PROJECT_ROOT = Path.cwd().resolve()
if PROJECT_ROOT.name == "notebooks":
    PROJECT_ROOT = PROJECT_ROOT.parent
OUTPUT_DIR = PROJECT_ROOT / "outputs" / "member2"
FIGURE_DIR = OUTPUT_DIR / "figures"
FIGURE_DIR.mkdir(parents=True, exist_ok=True)
""",
    )
    _set_cell(
        notebook,
        4,
        """
import sys

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from IPython.display import display

SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from group029_member2 import build_eda_summaries

orders = pd.read_csv(
    OUTPUT_DIR / f"{GROUP_ID}_orders_standardised.csv",
    keep_default_na=False,
    dtype={"order_id": "string", "coupon_code": "string", "promo_code": "string"},
)
order_items = pd.read_csv(
    OUTPUT_DIR / f"{GROUP_ID}_order_items_standardised.csv",
    keep_default_na=False,
    dtype={"order_item_id": "string", "order_id": "string", "product_id": "string"},
)
orders["order_timestamp"] = pd.to_datetime(
    orders["order_timestamp"], format="%Y-%m-%d %H:%M:%S", errors="raise"
)
sns.set_theme(style="whitegrid", context="notebook")
print({"orders": orders.shape, "order_items": order_items.shape})
""",
    )
    _set_cell(
        notebook,
        5,
        """
## 1. Context and data-preparation assurance

The member-2 transaction workflow standardises both structured sources before
comparison, records source overlap dynamically, blocks export on field conflict,
and independently recomputes all submitted arithmetic. `VAL-FLOW-ORD-01` and
`VAL-FLOW-ITM-01` reconcile the source-key unions; `VAL-FLOW-ORD-02` and
`VAL-FLOW-ITM-02` show zero normalised field conflicts; `VAL-ARITH-LINE-01` to
`VAL-ARITH-TOTAL-01` validate the published rounding, included-GST, discount and
delivery sequence. The figures below use one canonical order per observation,
avoiding item-level join multiplication.
""",
    )
    _set_cell(notebook, 6, "The complete field lineage remains in the 111-row mapping CSV.")
    _set_cell(
        notebook,
        12,
        """
### Figure 3: Order value by sales channel and coupon use

**Question:** How does order value vary by sales channel and coupon use?  
**Observation unit and denominator:** One canonical order; all 5,000 orders, with group sizes reported below.  
**Tables and join keys:** `orders`; no relational join is required.  
**Interpretation and limitation:** Compare medians and IQRs rather than claiming causation. `order_total` is post-discount, coupon allocation is not random, and outliers are hidden only in the chart while retained in calculations.
""",
    )
    _set_cell(
        notebook,
        13,
        """
orders["coupon_used"] = orders["coupon_discount"].gt(0).map(
    {True: "Coupon used", False: "No coupon"}
)
summaries = build_eda_summaries(
    orders.assign(order_timestamp=orders["order_timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S"))
)
display(summaries["channel_coupon"])

palette = {"No coupon": "#64748B", "Coupon used": "#0F766E"}
fig, ax = plt.subplots(figsize=(10, 6))
sns.boxplot(
    data=orders,
    x="sales_channel",
    y="order_total",
    hue="coupon_used",
    order=sorted(orders["sales_channel"].unique()),
    hue_order=["No coupon", "Coupon used"],
    palette=palette,
    showfliers=False,
    width=0.7,
    ax=ax,
)
fig.suptitle("Figure 3. Order value by sales channel and coupon use", x=0.08, y=0.98, ha="left", weight="bold", fontsize=15)
fig.text(0.08, 0.935, f"Observation unit: canonical order; denominator: {len(orders):,} orders; outliers hidden for readability", fontsize=9, color="#475569")
ax.set_xlabel("Sales channel")
ax.set_ylabel("Order total (AUD)")
ax.legend(title="", frameon=False)
sns.despine(ax=ax)
fig.tight_layout(rect=(0, 0, 1, 0.91))
fig.savefig(FIGURE_DIR / "Figure3_order_value_by_channel_and_coupon.png", dpi=200, bbox_inches="tight")
plt.show()
""",
    )
    _set_cell(
        notebook,
        14,
        """
### Figure 4: Monthly order activity and revenue

**Question:** How do monthly order counts and revenue vary across 2018?  
**Observation unit and denominator:** Canonical orders aggregated to calendar month; all 5,000 orders.  
**Tables and join keys:** `orders`; no relational join is required.  
**Interpretation and limitation:** Order-count peaks need not coincide with revenue peaks because order value varies. Only one historical year is available, month lengths differ, and the pattern is not evidence of stable seasonality.
""",
    )
    _set_cell(
        notebook,
        15,
        """
monthly = summaries["monthly"]
display(monthly)

fig, axes = plt.subplots(2, 1, figsize=(11, 8), sharex=True)
sns.lineplot(data=monthly, x="month", y="order_count", marker="o", linewidth=2.2, color="#0F766E", ax=axes[0])
sns.lineplot(data=monthly, x="month", y="revenue", marker="o", linewidth=2.2, color="#1D4ED8", ax=axes[1])
fig.suptitle("Figure 4. Monthly order activity and revenue", x=0.08, y=0.985, ha="left", weight="bold", fontsize=15)
fig.text(0.08, 0.95, "Observation units: canonical orders and calendar-month aggregates; one historical year", fontsize=9, color="#475569")
axes[0].set_xlabel("")
axes[0].set_ylabel("Orders")
axes[1].set_xlabel("Month")
axes[1].set_ylabel("Revenue (AUD)")
axes[1].tick_params(axis="x", rotation=45)
axes[1].yaxis.set_major_formatter(lambda value, _: f"${value/1_000_000:.2f}m")
sns.despine(fig=fig)
fig.tight_layout(rect=(0, 0, 1, 0.93))
fig.savefig(FIGURE_DIR / "Figure4_monthly_order_activity_and_revenue.png", dpi=200, bbox_inches="tight")
plt.show()
""",
    )
    _set_cell(
        notebook,
        22,
        """
## 3. Ten evidence-based findings

The final report requires exactly ten findings across all group members. Member 2 proposes the following three evidence-backed candidates; the group should renumber them during final integration.
""",
    )
    _set_cell(
        notebook,
        23,
        """
1. **Member-2 finding A (Figure 4):** December produced the highest monthly revenue while September produced the highest order count. At the monthly aggregate grain, this shows that transaction volume alone does not determine revenue; average order value and product mix also matter. The comparison covers all 5,000 canonical orders, but one year cannot establish a recurring seasonal pattern. The retailer should examine item/category composition before changing seasonal staffing or inventory.
2. **Member-2 finding B (Figure 3):** Median order totals are broadly similar across Mobile, Store and Web relative to the substantial within-channel IQRs. This weak channel separation suggests that channel alone may not be a decision-relevant value segment. The result remains descriptive because customer/product mix differs by channel. A follow-up should compare like-for-like product baskets or customer segments.
3. **Member-2 finding C (Figure 3):** In each channel, coupon orders have a lower post-discount median order total than non-coupon orders. The denominator is all 5,000 canonical orders with group sizes shown in the Figure 3 statistics. This is not evidence that coupons reduce purchasing: the total is mechanically post-discount and coupon allocation/product choice are not random. Incremental promotion analysis would require an exposure/control design.
""",
    )
    _set_cell(
        notebook,
        24,
        """
## 4. Five future machine-learning questions

The final report requires exactly five questions covering at least two problem types. Member 2 proposes one forecasting candidate for group integration.
""",
    )
    _set_cell(
        notebook,
        25,
        """
### Member-2 MLQ: Can weekly order volume by sales channel be forecast for fulfilment planning?

| Element | Response |
|---|---|
| EDA evidence | Figure 4 shows meaningful month-to-month order-count variation, while Figure 3 shows three active sales channels. |
| Business decision | Plan short-term warehouse labour and channel-support capacity. |
| Problem type and analysis unit | Forecasting; one week × sales channel. |
| Target or unsupervised objective | Number of orders in the following week for each channel. |
| Decision-time predictors | Lagged weekly order counts, rolling means/variation, calendar week/month/season and channel; only information complete before the forecast cutoff. |
| Validation split and metric | Expanding-window temporal validation; MAE plus WAPE, with a naive seasonal/last-period benchmark. |
| Leakage, fairness or deployment risk | Future orders must not enter rolling features. Only one year limits seasonal learning; holidays, campaigns and stock availability are absent, so drift and undercoverage are material deployment risks. |
""",
    )
    _set_cell(
        notebook,
        30,
        """
## 5. Limitations and conclusion

The transaction figures are observational and use only one historical year.
Figure 3 deliberately avoids causal promotion claims, and Figure 4 does not
label one-year monthly variation as stable seasonality. Both figures use the
canonical order grain, so order metrics are not inflated by repeated item rows.
Final group reporting must integrate the remaining tables and preserve the
six-category, four-table and two-relational-analysis requirements.
""",
    )
    _set_cell(notebook, 31, "Member 2 scope complete; group-level integration remains pending.")

    # Remove template placeholders owned by other members so every remaining
    # code cell is meaningful and executable in this scoped working copy.
    remove_indices = {
        8, 9, 10, 11,       # Figure 1-2 placeholders
        16, 17, 18, 19, 20, 21,  # Figure 5-8 placeholders
        26, 27, 28, 29,     # MLQ-2 to MLQ-5 placeholders
    }
    notebook["cells"] = [
        cell
        for index, cell in enumerate(notebook["cells"], start=1)
        if index not in remove_indices
    ]

    output_path = PROJECT_ROOT / "notebooks" / "Group029_member2_EDA_working.ipynb"
    output_path.write_text(
        json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    return output_path


if __name__ == "__main__":
    solution_path = build_solution_notebook()
    eda_path = build_eda_notebook()
    print(solution_path)
    print(eda_path)
