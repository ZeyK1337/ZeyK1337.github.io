"""Build a self-contained, raw-data-free Group029 member-2 handoff ZIP."""

from __future__ import annotations

import argparse
import shutil
import zipfile
from pathlib import Path


ROOT_FILES = ["README_MEMBER1.md", "README_MEMBER2.md"]
TREE_FILES = {
    "src": ["Group029_text_functions.py", "group029_member1.py", "group029_member2.py"],
    "tests": [
        "test_group029_mapping.py",
        "test_group029_member1.py",
        "test_group029_member2.py",
        "test_group029_text_functions.py",
    ],
    "tools": [
        "acceptance_check.py",
        "build_member2_handoff.py",
        "build_member2_notebooks.py",
    ],
    "mapping": [
        "Group029_source_to_target_mapping_member1.csv",
        "Group029_source_to_target_mapping_member1_member2.csv",
    ],
    "notebooks": [
        "Group029_member1_official_working.ipynb",
        "Group029_member1_member2_official_working.ipynb",
        "Group029_member2_EDA_working.ipynb",
    ],
    "templates": [
        "A1_public_text_test_cases.csv",
        "A1_source_to_target_mapping_template.csv",
    ],
}
OUTPUT_TREES = ["outputs/member1", "outputs/member1_member2", "outputs/member2"]


def _copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def build_handoff(project_root: Path, output_root: Path, name: str) -> tuple[Path, Path]:
    project_root = project_root.resolve()
    output_root = output_root.resolve()
    stage = output_root / name
    archive = output_root / f"{name}.zip"
    if stage.exists() or archive.exists():
        raise FileExistsError(f"Choose a new handoff name; target already exists: {name}")

    for relative in ROOT_FILES:
        _copy_file(project_root / relative, stage / relative)
    for directory, names in TREE_FILES.items():
        for filename in names:
            _copy_file(project_root / directory / filename, stage / directory / filename)

    eda_template = project_root / "templates" / "A1_EDA_template.ipynb"
    if not eda_template.is_file():
        fallback = (
            project_root.parents[1]
            / "work"
            / "templates_review"
            / "templates"
            / "A1_EDA_template.ipynb"
        )
        eda_template = fallback
    _copy_file(eda_template, stage / "templates" / "A1_EDA_template.ipynb")

    for relative in OUTPUT_TREES:
        source_dir = project_root / relative
        if not source_dir.is_dir():
            raise FileNotFoundError(source_dir)
        shutil.copytree(source_dir, stage / relative)

    staged_files = [path for path in stage.rglob("*") if path.is_file()]
    forbidden = [
        path
        for path in staged_files
        if "raw_package" in path.parts
        or path.name in {"Group029_commerce.json", "Group029_operations.xml"}
    ]
    if forbidden:
        raise AssertionError(f"Raw source files entered the handoff: {forbidden}")

    output_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path in sorted(staged_files):
            handle.write(path, Path(name) / path.relative_to(stage))
    with zipfile.ZipFile(archive) as handle:
        bad_member = handle.testzip()
        if bad_member is not None:
            raise AssertionError(f"Corrupt ZIP member: {bad_member}")
    return stage, archive


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()
    stage, archive = build_handoff(args.project_root, args.output_root, args.name)
    print(f"stage={stage}")
    print(f"archive={archive}")


if __name__ == "__main__":
    main()
