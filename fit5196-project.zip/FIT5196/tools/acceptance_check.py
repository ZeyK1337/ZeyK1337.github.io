"""Read-only clean-room acceptance checks for the Group029 member-2 handoff."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd


NULL_LIKE = {"", "nan", "null", "none", "<na>"}


def _load_notebook(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _semantic_missing_count(series: pd.Series) -> int:
    normalised = series.astype("string").str.strip().str.casefold()
    return int((series.isna() | normalised.fillna("").isin(NULL_LIKE)).sum())


def run_acceptance(project_root: Path) -> dict[str, Any]:
    project_root = project_root.resolve()
    sys.path.insert(0, str(project_root / "src"))
    from group029_member2 import (  # pylint: disable=import-outside-toplevel
        ORDER_COLUMNS,
        ORDER_ITEM_COLUMNS,
        REQUIRED_IDENTIFIER_COLUMNS,
    )

    member2_dir = project_root / "outputs" / "member2"
    orders_path = member2_dir / "Group029_orders_standardised.csv"
    items_path = member2_dir / "Group029_order_items_standardised.csv"
    validation_path = member2_dir / "Group029_member2_validation.csv"
    mapping_path = (
        project_root
        / "mapping"
        / "Group029_source_to_target_mapping_member1_member2.csv"
    )
    notebook_paths = [
        project_root
        / "notebooks"
        / "Group029_member1_member2_official_working.ipynb",
        project_root / "notebooks" / "Group029_member2_EDA_working.ipynb",
    ]
    figure_paths = [
        member2_dir / "figures" / "Figure3_order_value_by_channel_and_coupon.png",
        member2_dir / "figures" / "Figure4_monthly_order_activity_and_revenue.png",
    ]
    required_paths = [
        orders_path,
        items_path,
        validation_path,
        mapping_path,
        *notebook_paths,
        *figure_paths,
    ]
    missing_paths = [str(path) for path in required_paths if not path.is_file()]
    if missing_paths:
        raise AssertionError(f"Missing acceptance artifacts: {missing_paths}")

    orders = pd.read_csv(orders_path, keep_default_na=False, dtype=str)
    items = pd.read_csv(items_path, keep_default_na=False, dtype=str)
    validation = pd.read_csv(validation_path, keep_default_na=False, dtype=str)
    mapping = pd.read_csv(mapping_path, keep_default_na=False, dtype=str)

    assert orders.columns.tolist() == ORDER_COLUMNS
    assert items.columns.tolist() == ORDER_ITEM_COLUMNS

    frames = {"orders": orders, "order_items": items}
    id_missing_counts = {
        f"{table_name}.{column}": _semantic_missing_count(frames[table_name][column])
        for table_name, columns in REQUIRED_IDENTIFIER_COLUMNS.items()
        for column in columns
    }
    assert not any(id_missing_counts.values()), id_missing_counts
    assert orders["order_id"].is_unique
    assert items["order_item_id"].is_unique
    assert not set(items["order_id"]) - set(orders["order_id"])

    assert len(validation) == 22
    assert validation["status"].eq("PASS").all()
    assert len(mapping) == 111
    completed = mapping["output_table"].isin(
        ["customers", "products", "orders", "order_items"]
    )
    assert int(completed.sum()) == 70
    assert int(mapping["output_table"].isin(["orders", "order_items"]).sum()) == 29

    notebook_results = []
    for path in notebook_paths:
        notebook = _load_notebook(path)
        code_cells = [
            cell
            for cell in notebook["cells"]
            if cell.get("cell_type") == "code" and "".join(cell.get("source", [])).strip()
        ]
        error_outputs = [
            output
            for cell in code_cells
            for output in cell.get("outputs", [])
            if output.get("output_type") == "error"
        ]
        unexecuted = [cell for cell in code_cells if cell.get("execution_count") is None]
        assert not error_outputs, f"Notebook errors in {path.name}: {error_outputs[:1]}"
        assert not unexecuted, f"Unexecuted code cells in {path.name}: {len(unexecuted)}"
        notebook_results.append(
            {"name": path.name, "executed_code_cells": len(code_cells), "errors": 0}
        )

    report = {
        "status": "PASS",
        "project_root": str(project_root),
        "orders_shape": list(orders.shape),
        "order_items_shape": list(items.shape),
        "required_id_semantic_missing_counts": id_missing_counts,
        "orders_primary_key_unique": True,
        "order_items_primary_key_unique": True,
        "item_to_order_unknown_count": 0,
        "validation_checks": len(validation),
        "validation_failures": int(validation["status"].ne("PASS").sum()),
        "mapping_rows": len(mapping),
        "mapping_completed_rows": int(completed.sum()),
        "notebooks": notebook_results,
        "figures": [
            {"name": path.name, "bytes": path.stat().st_size} for path in figure_paths
        ],
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = run_acceptance(args.project_root)
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
